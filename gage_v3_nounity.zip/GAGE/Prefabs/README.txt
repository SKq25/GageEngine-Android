Drop prefabs here named after entity types (tree, rock, house, enemy...). GAGE will use them instead of the built-in shapes.
