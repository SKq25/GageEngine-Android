using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace GAGE
{
    public class ChatMessage { public string role; public string content; }

    /// <summary>Talks to the GAGE proxy (key stays on the server). Model is always Gemini 2.5 Flash. Async: await it from UI code.</summary>
    public static class AIClient
    {
        public static readonly HttpClient Http = new HttpClient { Timeout = TimeSpan.FromSeconds(90) };
        class Req { public string model; public List<ChatMessage> messages; public float temperature; public int max_tokens; }

        public static Task<string> Chat(string system, string user, float temp = 0.7f, int maxTokens = 6000)
        {
            return Chat(new List<ChatMessage> { new ChatMessage { role = "system", content = system }, new ChatMessage { role = "user", content = user } }, temp, maxTokens);
        }

        /// <summary>Returns the assistant text, or throws Exception(readable message).</summary>
        public static async Task<string> Chat(List<ChatMessage> msgs, float temp = 0.7f, int maxTokens = 6000)
        {
            if (!GAGEConfig.IsConfigured) throw new Exception("AI server set nahi hai. gage_config.json me endpoint daalo (README dekho).");
            string url = GAGEConfig.DirectMode ? GAGEConfig.DirectUrl : GAGEConfig.Endpoint;
            string body = GJson.To(new Req { model = GAGEConfig.Model, messages = msgs, temperature = temp, max_tokens = maxTokens });
            string text;
            try
            {
                using (var req = new HttpRequestMessage(HttpMethod.Post, url))
                {
                    req.Content = new StringContent(body, Encoding.UTF8, "application/json");
                    if (GAGEConfig.DirectMode) req.Headers.TryAddWithoutValidation("Authorization", "Bearer " + GAGEConfig.DevKey);
                    else if (!string.IsNullOrEmpty(GAGEConfig.AccessToken)) req.Headers.TryAddWithoutValidation("X-GAGE-Access", GAGEConfig.AccessToken);
                    using (var resp = await Http.SendAsync(req))
                    {
                        text = await resp.Content.ReadAsStringAsync();
                        if (!resp.IsSuccessStatusCode) throw new Exception("AI error " + (int)resp.StatusCode + " " + Short(text));
                    }
                }
            }
            catch (HttpRequestException e) { throw new Exception("AI network error: " + e.Message); }
            catch (TaskCanceledException) { throw new Exception("AI timeout. Dobara try karo."); }
            try
            {
                using (var doc = JsonDocument.Parse(text))
                {
                    var ch = doc.RootElement.GetProperty("choices");
                    if (ch.GetArrayLength() == 0) throw new Exception("AI ka khali jawab aaya.");
                    return ch[0].GetProperty("message").GetProperty("content").GetString() ?? "";
                }
            }
            catch (JsonException e) { throw new Exception("AI parse error: " + e.Message); }
            catch (KeyNotFoundException) { throw new Exception("AI ka jawab samajh nahi aaya: " + Short(text)); }
        }

        static string Short(string s) { return string.IsNullOrEmpty(s) ? "" : (s.Length > 160 ? s.Substring(0, 160) : s); }

        /// <summary>Pull the first {...} JSON object out of a reply (handles ```json fences).</summary>
        public static string ExtractJson(string s)
        {
            if (string.IsNullOrEmpty(s)) return null;
            int a = s.IndexOf('{'), b = s.LastIndexOf('}'); return (a >= 0 && b > a) ? s.Substring(a, b - a + 1) : null;
        }
    }
}
