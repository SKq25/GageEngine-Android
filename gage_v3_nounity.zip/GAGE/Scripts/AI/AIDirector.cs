using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Godot;

namespace GAGE
{
    /// <summary>Turns plain-language ideas into a playable 3D game (Generate) or edits the current one (Edit). Same prompts as the Unity version.</summary>
    public static class AIDirector
    {
        const string Ops = @"
OPERATIONS (field 'ops'): each op is one of:
 {""op"":""add"",""type"":T,""count"":N,""cx"":X,""cz"":Z,""radius"":R,""exact"":false,""scale"":1,""scaleVar"":0.3,""color"":""#RRGGBB"",""behavior"":""chase|wander|patrol"",""speed"":3,""points"":1,""text"":""npc persona""}
   -> scatters N objects of type T randomly inside the circle (cx,cz,radius). radius 0 = whole map. exact:true puts ONE at exactly (cx,cz).
 {""op"":""remove"",""type"":T or ""all"",""cx"":X,""cz"":Z,""radius"":R}  (radius 0 = whole map)
 {""op"":""world"",""world"":{""biome"":""grassland|forest|desert|snow|volcanic"",""timeOfDay"":0-24,""fog"":0.001-0.03,""waterLevel"":0-12,""heightScale"":4-40,""size"":60-250,""seed"":int,""title"":"""",""targetScore"":int}}  (only include fields to change)
TYPES: tree, pine, rock, house, tower, crate, lamp, enemy, coin, npc, spawn.
Map coordinates are in meters, range -size/2..size/2. Never put y. Omit unused fields.";

        const string GenSystem = @"You are GAGE, the AI director of a 3D game engine. Convert the user's idea into ONE JSON object and NOTHING else (no markdown, no prose).
{""world"":{""title"":"""",""description"":"""",""seed"":1,""size"":120,""heightScale"":14,""roughness"":0.5,""biome"":""grassland"",""waterLevel"":2.5,""timeOfDay"":15,""fog"":0.006},
 ""player"":{""speed"":6,""health"":5},""targetScore"":10,""winText"":""You Win!"",""loseText"":""Game Over"",
 ""ops"":[ ...operations... ]}
RULES: exactly one spawn op near (0,0) with exact:true. Include coins whose total points >= targetScore (the player wins by collecting them). Put enemies far from spawn. Use realistic proportions: size 100-200, 80-250 total objects, mix of tree/pine/rock, a few houses, lamps for night maps. Choose biome/timeOfDay/fog to match the mood (night = timeOfDay 22, fog 0.012). Keep under 20 ops." + Ops;

        const string EditSystem = @"You are GAGE, the AI assistant inside a 3D game editor. The user asks for a change to the current world. Reply with ONE JSON object and NOTHING else: {""reply"":""one short friendly sentence in the user's language"",""ops"":[...]}." + Ops;

        /// <summary>Throws Exception(readable message) on failure.</summary>
        public static async Task<AIGame> Generate(string prompt)
        {
            string raw = await AIClient.Chat(GenSystem, "Game idea: " + prompt, 0.8f, 7000);
            string j = AIClient.ExtractJson(raw); if (j == null) throw new Exception("AI ne JSON nahi diya. Dobara try karo.");
            AIGame g;
            try { g = GJson.From<AIGame>(j); } catch (JsonException e) { throw new Exception("AI parse error: " + e.Message); }
            if (g == null) throw new Exception("AI JSON samajh nahi aaya.");
            if (g.world == null) g.world = new WorldData(); if (g.player == null) g.player = new PlayerData();
            g.world.size = Mathf.Clamp(g.world.size, 60f, 250f); g.world.heightScale = Mathf.Clamp(g.world.heightScale, 3f, 40f);
            g.world.timeOfDay = U.Repeat(g.world.timeOfDay, 24f); g.world.waterLevel = Mathf.Clamp(g.world.waterLevel, 0f, g.world.heightScale * 0.45f);
            if (g.ops == null) g.ops = new AIOp[0];
            return g;
        }

        public static async Task<AIOps> Edit(string prompt, SceneBuilder sb)
        {
            var counts = new Dictionary<string, int>();
            foreach (var e in sb.Data.entities) { int c; counts.TryGetValue(e.type, out c); counts[e.type] = c + 1; }
            var sbd = new StringBuilder(); foreach (var kv in counts) sbd.Append(kv.Key).Append('=').Append(kv.Value).Append(' ');
            var w = sb.Data.world;
            string ctx = "CURRENT WORLD: biome=" + w.biome + " size=" + w.size + " timeOfDay=" + w.timeOfDay + " waterLevel=" + w.waterLevel + " fog=" + w.fog + " objects: " + sbd + "\nREQUEST: " + prompt;
            string raw = await AIClient.Chat(EditSystem, ctx, 0.6f, 3000);
            string j = AIClient.ExtractJson(raw); if (j == null) throw new Exception("AI ne JSON nahi diya.");
            AIOps o;
            try { o = GJson.From<AIOps>(j); } catch (JsonException e) { throw new Exception("AI parse error: " + e.Message); }
            if (o == null) throw new Exception("AI JSON samajh nahi aaya.");
            return o;
        }
    }
}
