using System;
using System.Collections.Generic;
using Godot;

namespace GAGE
{
    /// <summary>An NPC you can talk to (child of the npc entity). Replies come from Gemini 2.5 Flash.</summary>
    public partial class AINpc : Node
    {
        public static readonly List<AINpc> All = new List<AINpc>();
        public string persona = "A friendly villager."; readonly List<ChatMessage> hist = new List<ChatMessage>();
        public override void _EnterTree() { All.Add(this); }
        public override void _ExitTree() { All.Remove(this); }

        public static AINpc Nearest(Vector3 p, float r)
        {
            AINpc best = null; float bd = r * r;
            foreach (var n in All)
            {
                var b = n.GetParent() as Node3D; if (b == null) continue;
                float d = (b.GlobalPosition - p).LengthSquared(); if (d < bd) { bd = d; best = n; }
            }
            return best;
        }

        public async void Talk(string userMsg, Action<string> reply)
        {
            if (hist.Count == 0) hist.Add(new ChatMessage { role = "system", content = "You are an NPC in a 3D game. Persona: " + persona + ". Goal of the game: collect coins and avoid enemies. Reply in max 2 short sentences, in the player's language, stay in character." });
            hist.Add(new ChatMessage { role = "user", content = userMsg });
            if (hist.Count > 9) hist.RemoveRange(1, 2);
            try
            {
                string r = await AIClient.Chat(hist, 0.9f, 200);
                hist.Add(new ChatMessage { role = "assistant", content = r }); reply(r.Trim());
            }
            catch (Exception) { reply("..."); }
        }
    }
}
