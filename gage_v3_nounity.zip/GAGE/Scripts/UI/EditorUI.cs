using System;
using System.Collections.Generic;
using System.Text;
using Godot;

namespace GAGE
{
    /// <summary>
    /// The whole in-game UI, built from code (no scene file needed): top bar, drag&amp;drop palette, selection toolbar, AI panel,
    /// Sketchfab asset browser, multiplayer panel, play HUD with virtual joystick. Layout = same fractions as the Unity version.
    /// </summary>
    public partial class EditorUI : CanvasLayer
    {
        bool playerMode; Control root, editGroup, playGroup, topBar, toolbar, aiPanel, assetsPanel, mpPanel, talkBtn, restartBtn;
        Label status, hud, banner, speech, mpInfo, mpScore; Button playBtn;
        TextEdit promptField; LineEdit searchField, mpName, mpRoom;
        Panel joyBg, joyKnob;
        bool busy; float statusT, speechT; readonly StringBuilder sbHud = new StringBuilder();

        static readonly Color Dark = new Color(.08f, .09f, .12f, .86f), Blue = new Color(.18f, .42f, .85f), Green = new Color(.15f, .6f, .3f),
                              Red = new Color(.75f, .2f, .2f), Gray = new Color(.25f, .27f, .33f), Purple = new Color(.5f, .3f, .85f);

        // Sketchfab results
        readonly List<SketchfabClient.Result> found = new List<SketchfabClient.Result>();
        readonly Button[] rowBtn = new Button[6], rowOpen = new Button[6];

        public override void _Ready()
        {
            Layer = 10;
            BuildUI();
            InputHub.I.JoyRect = () => joyBg.GetGlobalRect();
            var bundled = GameBundle.Exists ? GameBundle.Load() : null;
            if (bundled != null) { playerMode = true; topBar.Visible = false; SceneBuilder.I.Load(bundled); SceneBuilder.I.SetPlaying(true); playBtn.Text = "STOP"; }
            else SceneBuilder.I.LoadGame(SceneStore.Demo());
            Say("GAGE ready. Palette se object kheencho, ya AI se game banao.  " + NativeBridge.Status);
        }

        // ------------- UI helpers -------------
        static void Anchor(Control c, float x0, float y0, float x1, float y1)
        {
            // fractions with the origin at the bottom-left (like Unity); Godot's origin is top-left
            c.AnchorLeft = x0; c.AnchorRight = x1; c.AnchorTop = 1f - y1; c.AnchorBottom = 1f - y0;
            c.OffsetLeft = 0; c.OffsetRight = 0; c.OffsetTop = 0; c.OffsetBottom = 0;
        }

        static StyleBoxFlat Flat(Color c, int radius = 6)
        {
            var s = new StyleBoxFlat { BgColor = c }; s.SetCornerRadiusAll(radius); return s;
        }

        Control Group(Control parent)
        {
            var g = new Control { MouseFilter = Control.MouseFilterEnum.Ignore }; parent.AddChild(g); g.SetAnchorsPreset(Control.LayoutPreset.FullRect); return g;
        }

        ColorRect Pnl(Control parent, float x0, float y0, float x1, float y1, Color c, bool blocker = true)
        {
            var r = new ColorRect { Color = c, MouseFilter = blocker ? Control.MouseFilterEnum.Stop : Control.MouseFilterEnum.Ignore };
            parent.AddChild(r); Anchor(r, x0, y0, x1, y1); if (blocker) InputHub.I.Blockers.Add(r); return r;
        }

        Label Lbl(Control parent, string txt, int size, HorizontalAlignment ha, VerticalAlignment va, float x0, float y0, float x1, float y1)
        {
            var l = new Label { Text = txt, HorizontalAlignment = ha, VerticalAlignment = va, AutowrapMode = TextServer.AutowrapMode.WordSmart, ClipText = true, MouseFilter = Control.MouseFilterEnum.Ignore };
            l.AddThemeFontSizeOverride("font_size", size); l.AddThemeColorOverride("font_outline_color", new Color(0, 0, 0, .8f)); l.AddThemeConstantOverride("outline_size", 4);
            parent.AddChild(l); Anchor(l, x0, y0, x1, y1); return l;
        }

        static void Style(Button b, Color c)
        {
            b.AddThemeStyleboxOverride("normal", Flat(c)); b.AddThemeStyleboxOverride("hover", Flat(c.Lightened(.1f)));
            b.AddThemeStyleboxOverride("pressed", Flat(c.Lightened(.28f))); b.AddThemeStyleboxOverride("focus", Flat(c)); b.AddThemeStyleboxOverride("disabled", Flat(c.Darkened(.4f)));
        }

        Button Btn(Control parent, string txt, float x0, float y0, float x1, float y1, Color c, Action act, int size = 22)
        {
            var b = new Button { Text = txt, FocusMode = Control.FocusModeEnum.None, ClipText = true };
            b.AddThemeFontSizeOverride("font_size", size); Style(b, c);
            if (act != null) b.Pressed += act;
            parent.AddChild(b); Anchor(b, x0, y0, x1, y1); InputHub.I.Blockers.Add(b); return b;
        }

        /// <summary>Button anchored to a screen corner with a fixed pixel size. pos = offset of its centre from the anchor (y up, like Unity).</summary>
        Button FixedBtn(Control parent, string txt, Vector2 anchor, Vector2 pos, Vector2 size, Color c, Action act)
        {
            var b = new Button { Text = txt, FocusMode = Control.FocusModeEnum.None };
            b.AddThemeFontSizeOverride("font_size", 26); Style(b, c); b.Pressed += act; parent.AddChild(b);
            b.AnchorLeft = b.AnchorRight = anchor.X; b.AnchorTop = b.AnchorBottom = 1f - anchor.Y;
            b.OffsetLeft = pos.X - size.X / 2; b.OffsetRight = pos.X + size.X / 2; b.OffsetTop = -pos.Y - size.Y / 2; b.OffsetBottom = -pos.Y + size.Y / 2;
            InputHub.I.Blockers.Add(b); return b;
        }

        static void StyleField(Control f)
        {
            f.AddThemeStyleboxOverride("normal", Flat(new Color(1, 1, 1, .95f), 4)); f.AddThemeStyleboxOverride("focus", Flat(new Color(1, 1, 1, 1f), 4));
            f.AddThemeColorOverride("font_color", Colors.Black); f.AddThemeColorOverride("font_placeholder_color", new Color(.4f, .4f, .45f));
            f.AddThemeColorOverride("caret_color", Colors.Black); f.AddThemeFontSizeOverride("font_size", 22);
        }

        LineEdit LineF(Control parent, string ph, float x0, float y0, float x1, float y1)
        {
            var f = new LineEdit { PlaceholderText = ph }; StyleField(f); parent.AddChild(f); Anchor(f, x0, y0, x1, y1); InputHub.I.Blockers.Add(f); return f;
        }
        TextEdit MultiF(Control parent, string ph, float x0, float y0, float x1, float y1)
        {
            var f = new TextEdit { PlaceholderText = ph, WrapMode = TextEdit.LineWrappingMode.Boundary }; StyleField(f);
            parent.AddChild(f); Anchor(f, x0, y0, x1, y1); InputHub.I.Blockers.Add(f); return f;
        }

        void BuildUI()
        {
            root = new Control { Name = "GAGE UI", MouseFilter = Control.MouseFilterEnum.Ignore }; AddChild(root); root.SetAnchorsPreset(Control.LayoutPreset.FullRect);

            // top bar (always visible)
            topBar = Pnl(root, 0, .92f, 1, 1, Dark);
            playBtn = Btn(topBar, "PLAY", .01f, .1f, .12f, .9f, Green, TogglePlay);
            editGroup = Group(root);
            var topEdit = Group(editGroup);
            Btn(topEdit, "SAVE", .13f, .925f, .20f, .995f, Gray, DoSave); Btn(topEdit, "LOAD", .21f, .925f, .28f, .995f, Gray, DoLoad);
            Btn(topEdit, "DEMO", .29f, .925f, .36f, .995f, Gray, () => { SceneBuilder.I.LoadGame(SceneStore.Demo()); Say("Demo level load hua."); });
            Btn(topEdit, "EXPORT", .37f, .925f, .45f, .995f, Gray, DoExport, 18);
            Btn(topEdit, "AI", .46f, .925f, .51f, .995f, Purple, () => { aiPanel.Visible = !aiPanel.Visible; assetsPanel.Visible = false; mpPanel.Visible = false; });
            Btn(topEdit, "ASSETS", .52f, .925f, .60f, .995f, Blue, () => { assetsPanel.Visible = !assetsPanel.Visible; aiPanel.Visible = false; mpPanel.Visible = false; });
            Btn(topEdit, "MP", .61f, .925f, .66f, .995f, Green, () => { mpPanel.Visible = !mpPanel.Visible; aiPanel.Visible = false; assetsPanel.Visible = false; });
            status = Lbl(root, "", 17, HorizontalAlignment.Left, VerticalAlignment.Center, .67f, .92f, .995f, 1f);

            // palette (drag & drop)
            var pal = Pnl(editGroup, 0, .12f, .2f, .92f, Dark);
            Lbl(pal, "DRAG INTO WORLD", 16, HorizontalAlignment.Center, VerticalAlignment.Center, 0, .94f, 1, 1);
            for (int i = 0; i < EntityTypes.Palette.Length; i++)
            {
                int col = i % 2, row = i / 2; float cw = .5f, ch = .94f / 6f;
                float x0 = col * cw + .02f, x1 = (col + 1) * cw - .02f, y1 = .94f - row * ch - .01f, y0 = y1 - ch + .02f;
                string type = EntityTypes.Palette[i];
                var b = Btn(pal, type.ToUpper(), x0, y0, x1, y1, Gray, () => { if (!InputHub.I.ConsumePalDragged()) DropInFront(type); }, 16);
                b.ButtonDown += () => InputHub.I.PaletteType = type;
            }

            // selection toolbar
            toolbar = Pnl(editGroup, .22f, .01f, .99f, .1f, Dark);
            string[] names = { "ROT -", "ROT +", "BIGGER", "SMALLER", "COPY", "DELETE" };
            Action[] acts = { () => EditorController.I.RotateSel(-30), () => EditorController.I.RotateSel(30), () => EditorController.I.ScaleSel(1.2f),
                              () => EditorController.I.ScaleSel(1f / 1.2f), () => EditorController.I.DuplicateSel(), () => EditorController.I.DeleteSel() };
            for (int i = 0; i < 6; i++) Btn(toolbar, names[i], i / 6f + .005f, .1f, (i + 1) / 6f - .005f, .9f, i == 5 ? Red : Gray, acts[i], 20);

            // AI panel
            aiPanel = Pnl(editGroup, .22f, .12f, .99f, .5f, Dark);
            Lbl(aiPanel, "AI (Gemini 2.5 Flash): game idea ya badlav likho", 18, HorizontalAlignment.Left, VerticalAlignment.Center, .02f, .84f, .98f, .98f);
            promptField = MultiF(aiPanel, "e.g. Raat ka jungle, 10 coins, 4 khatarnak enemies, ek purana ghar...", .02f, .35f, .98f, .84f);
            Btn(aiPanel, "GENERATE GAME", .02f, .04f, .49f, .31f, Purple, RunGenerate);
            Btn(aiPanel, "EDIT WORLD", .51f, .04f, .98f, .31f, Blue, RunEdit); aiPanel.Visible = false;

            BuildAssetsPanel();

            // play group
            playGroup = Group(root);
            hud = Lbl(playGroup, "", 30, HorizontalAlignment.Left, VerticalAlignment.Top, .015f, .8f, .5f, .91f);
            banner = Lbl(playGroup, "", 64, HorizontalAlignment.Center, VerticalAlignment.Center, .1f, .4f, .9f, .65f);
            speech = Lbl(playGroup, "", 26, HorizontalAlignment.Center, VerticalAlignment.Center, .2f, .12f, .8f, .24f);
            joyBg = new Panel { MouseFilter = Control.MouseFilterEnum.Ignore }; joyBg.AddThemeStyleboxOverride("panel", Flat(new Color(1, 1, 1, .18f), 130));
            playGroup.AddChild(joyBg); joyBg.AnchorLeft = joyBg.AnchorRight = 0; joyBg.AnchorTop = joyBg.AnchorBottom = 1;
            joyBg.OffsetLeft = 60; joyBg.OffsetRight = 320; joyBg.OffsetTop = -320; joyBg.OffsetBottom = -60;
            joyKnob = new Panel { MouseFilter = Control.MouseFilterEnum.Ignore, CustomMinimumSize = new Vector2(110, 110), Size = new Vector2(110, 110) };
            joyKnob.AddThemeStyleboxOverride("panel", Flat(new Color(1, 1, 1, .55f), 55)); joyBg.AddChild(joyKnob);
            FixedBtn(playGroup, "JUMP", new Vector2(1, 0), new Vector2(-150, 170), new Vector2(190, 190), Green, () => InputHub.I.QueueJump());
            talkBtn = FixedBtn(playGroup, "TALK", new Vector2(1, 0), new Vector2(-150, 360), new Vector2(190, 90), Purple, DoTalk);
            restartBtn = FixedBtn(playGroup, "RESTART", new Vector2(.5f, 0), new Vector2(0, 130), new Vector2(320, 100), Blue, () => SceneBuilder.I.RebuildEntities(true)); restartBtn.Visible = false;
            var online = FixedBtn(playGroup, "ONLINE", new Vector2(1, 1), new Vector2(-110, -60), new Vector2(190, 80), Green, () => mpPanel.Visible = !mpPanel.Visible);
            online.Visible = GameBundle.Exists;
            playGroup.Visible = false;
            BuildMpPanel();
        }

        public void Say(string s) { status.Text = s; statusT = U.Now; }

        // ------------- multiplayer panel -------------
        void BuildMpPanel()
        {
            mpPanel = Pnl(GameBundle.Exists ? root : editGroup, .22f, .12f, .99f, .6f, Dark);
            Lbl(mpPanel, "ONLINE CO-OP  (host ek room banata hai, dost 4-letter code se join karte hain)", 18, HorizontalAlignment.Left, VerticalAlignment.Center, .02f, .88f, .98f, .99f);
            mpName = LineF(mpPanel, "Tumhara naam", .02f, .70f, .48f, .87f); mpName.Text = MultiplayerClient.I != null ? MultiplayerClient.I.PlayerName : "Player";
            mpRoom = LineF(mpPanel, "Room code (e.g. K7QD)", .52f, .70f, .98f, .87f); mpRoom.MaxLength = 4;
            Btn(mpPanel, "HOST ROOM", .02f, .46f, .32f, .67f, Green, () => { ApplyMpName(); MultiplayerClient.I.Host(); });
            Btn(mpPanel, "JOIN ROOM", .35f, .46f, .65f, .67f, Blue, () => { ApplyMpName(); MultiplayerClient.I.Join(mpRoom.Text); });
            Btn(mpPanel, "LEAVE", .68f, .46f, .98f, .67f, Red, () => MultiplayerClient.I.Leave());
            mpInfo = Lbl(mpPanel, "", 20, HorizontalAlignment.Left, VerticalAlignment.Top, .02f, .02f, .98f, .43f);
            mpPanel.Visible = false;
            mpScore = Lbl(playGroup, "", 22, HorizontalAlignment.Left, VerticalAlignment.Top, .015f, .62f, .5f, .8f);
        }

        void ApplyMpName() { if (MultiplayerClient.I != null) MultiplayerClient.I.SetName(mpName.Text); }

        void UpdateMpHud(bool play)
        {
            var mc = MultiplayerClient.I; if (mc == null || mpInfo == null) return;
            if (mpPanel.Visible)
            {
                sbHud.Clear();
                if (!MultiplayerClient.Available) sbHud.Append("Server endpoint set nahi hai (gage_config.json).\n");
                if (mc.Joined)
                {
                    sbHud.Append("ROOM: ").Append(mc.Room).Append(mc.IsHost ? "  (tum host ho)" : "").Append("\nOnline: ").Append(mc.Others.Count + 1).Append(" player\n");
                    foreach (var o in mc.Others) sbHud.Append(" - ").Append(o.name).Append(o.host ? " (host)" : "").Append('\n');
                    sbHud.Append("Ab sab PLAY dabao. Coins sabke beech shared hain.");
                }
                if (!string.IsNullOrEmpty(mc.Status)) sbHud.Append('\n').Append(mc.Status);
                mpInfo.Text = sbHud.ToString();
            }
            if (play)
            {
                if (!mc.Joined) { mpScore.Text = ""; return; }
                sbHud.Clear(); sbHud.Append("ROOM ").Append(mc.Room).Append("\n").Append(mc.PlayerName).Append(": ").Append(mc.MyScore);
                foreach (var o in mc.Others) sbHud.Append("\n").Append(o.name).Append(": ").Append(o.score);
                mpScore.Text = sbHud.ToString();
            }
            if (!string.IsNullOrEmpty(mc.Status) && !mpPanel.Visible && U.Now - statusT > 2f && mc.Status.StartsWith("Connection")) Say(mc.Status);
        }

        // ------------- Sketchfab asset browser -------------
        void BuildAssetsPanel()
        {
            assetsPanel = Pnl(editGroup, .22f, .12f, .99f, .72f, Dark);
            searchField = LineF(assetsPanel, "Sketchfab search: tree, car, house, dragon...", .02f, .88f, .70f, .98f);
            Btn(assetsPanel, "SEARCH", .72f, .88f, .98f, .98f, Blue, RunSearch);
            for (int i = 0; i < 6; i++)
            {
                float y1 = .85f - i * .135f, y0 = y1 - .12f; int k = i;
                rowBtn[i] = Btn(assetsPanel, "-", .02f, y0, .80f, y1, Gray, () => ImportRow(k), 18);
                rowOpen[i] = Btn(assetsPanel, "OPEN", .82f, y0, .98f, y1, Gray, () => OpenRow(k), 18);
                rowBtn[i].Visible = false; rowOpen[i].Visible = false;
            }
            assetsPanel.Visible = false;
        }

        async void RunSearch()
        {
            string q = searchField.Text; if (busy || string.IsNullOrWhiteSpace(q)) return; busy = true; Say("Sketchfab search...");
            try
            {
                var list = await SketchfabClient.Search(q);
                found.Clear(); found.AddRange(list);
                for (int i = 0; i < 6; i++)
                {
                    bool has = i < found.Count; rowBtn[i].Visible = has; rowOpen[i].Visible = has;
                    if (has) rowBtn[i].Text = found[i].name + "  -  " + found[i].author + "  (" + found[i].faces + " faces)";
                }
                Say(found.Count + " models mile. Naam dabao = import, OPEN = browser me dekho.");
            }
            catch (Exception e) { Say(e.Message); }
            finally { busy = false; }
        }

        void OpenRow(int i) { if (i < found.Count) OS.ShellOpen(found[i].viewerUrl); }

        async void ImportRow(int i)
        {
            if (busy || i >= found.Count) return; var r = found[i]; busy = true; Say("Download: " + r.name + " ...");
            try
            {
                await SketchfabClient.Download(r.uid, GAGEConfig.SketchfabToken);
                Vector3 p; var vis = GetViewport().GetVisibleRect().Size;
                if (!EditorController.I.RayTerrain(new Vector2(vis.X * .6f, vis.Y * .5f), out p)) p = Vector3.Zero;
                var ge = SceneBuilder.I.AddModel(r.uid, p); EditorController.I.Select(ge);
                Say("Model add hua: " + r.name + ". (License/credit: " + r.author + ")");
            }
            catch (Exception e) { Say(e.Message); }
            finally { busy = false; }
        }

        // ------------- actions -------------
        void TogglePlay()
        {
            if (busy) return; var sb = SceneBuilder.I; sb.SetPlaying(!sb.Playing);
            playBtn.Text = sb.Playing ? "STOP" : "PLAY"; Say(sb.Playing ? "Game chal raha hai" : "Edit mode");
        }
        void DoSave() { SceneBuilder.I.Capture(); SceneStore.Save(SceneBuilder.I.Data); Say("Saved: " + SceneBuilder.I.Data.world.title); }
        void DoLoad() { if (!SceneStore.Exists) { Say("Koi saved game nahi mila."); return; } SceneBuilder.I.Load(SceneStore.Load()); Say("Loaded."); }
        void DoExport()
        {
            var sb = SceneBuilder.I; sb.Capture(); OS.RequestPermissions();
            string name, json; string path = GameBundle.ExportZip(sb.Data, out name, out json);
            if (path == null) { Say("Export fail hua."); return; }
            DisplayServer.ClipboardSet(json);
            Say("Export ho gaya: " + path + "  (game JSON clipboard me bhi copy hua). GitHub me game.zip naam se daalo.");
        }
        void DropInFront(string type)
        {
            Vector3 p; var vis = GetViewport().GetVisibleRect().Size;
            if (!EditorController.I.RayTerrain(new Vector2(vis.X * .6f, vis.Y * .5f), out p)) return;
            var ge = SceneBuilder.I.AddEntity(type, p); EditorController.I.Select(ge);
        }
        async void RunGenerate()
        {
            string p = promptField.Text; if (busy || string.IsNullOrWhiteSpace(p)) return; busy = true; Say("AI game bana raha hai...");
            try { var g = await AIDirector.Generate(p); SceneBuilder.I.LoadGame(g); aiPanel.Visible = false; playBtn.Text = "PLAY"; Say("Game ready: " + g.world.title); }
            catch (Exception e) { Say(e.Message); }
            finally { busy = false; }
        }
        async void RunEdit()
        {
            string p = promptField.Text; if (busy || string.IsNullOrWhiteSpace(p)) return; busy = true; Say("AI badlav kar raha hai...");
            try { var o = await AIDirector.Edit(p, SceneBuilder.I); Say(SceneBuilder.I.ApplyOps(o)); }
            catch (Exception e) { Say(e.Message); }
            finally { busy = false; }
        }
        void DoTalk()
        {
            var sb = SceneBuilder.I; if (sb.Player == null) return; var n = AINpc.Nearest(sb.Player.GlobalPosition, 5f); if (n == null) return;
            speech.Text = "..."; speechT = U.Now; n.Talk("Hi! Mujhe ek chhota hint do.", r => { speech.Text = r; speechT = U.Now; });
        }

        public override void _Process(double delta)
        {
            var sb = SceneBuilder.I; var gs = GameSession.I; if (sb == null || sb.Terrain == null || root == null) return; bool play = sb.Playing;
            editGroup.Visible = !play && !playerMode; playGroup.Visible = play;
            if (!play) { UpdateMpHud(false); toolbar.Visible = EditorController.I.Selected != null && GodotObject.IsInstanceValid(EditorController.I.Selected); }
            else
            {
                string goal = gs.Target > 0 ? gs.Score + "/" + gs.Target : gs.Score.ToString();
                hud.Text = "COINS " + goal + "    HEALTH " + gs.Health; UpdateMpHud(true);
                banner.Text = gs.State == GameState.Won ? gs.WinText : (gs.State == GameState.Lost ? gs.LoseText : "");
                banner.AddThemeColorOverride("font_color", gs.State == GameState.Won ? new Color(.4f, 1f, .5f) : new Color(1f, .4f, .4f));
                restartBtn.Visible = playerMode && gs.State != GameState.Playing;
                talkBtn.Visible = sb.Player != null && AINpc.Nearest(sb.Player.GlobalPosition, 5f) != null;
                if (ScriptHost.MessageTime > speechT) { speech.Text = ScriptHost.Message; speechT = ScriptHost.MessageTime; }
                if (speech.Text.Length > 0 && U.Now - speechT > 8f) speech.Text = "";
                var mv = InputHub.I.Move; joyKnob.Position = new Vector2(75f + mv.X * 100f, 75f - mv.Y * 100f);
            }
            if (status.Text.Length > 0 && U.Now - statusT > 12f && !busy) status.Text = "";
        }
    }
}
