using System.Collections.Generic;
using Godot;

namespace GAGE
{
    /// <summary>Edit mode: tap to select, drag to move, drag empty space to orbit, two fingers to pan/zoom. Input arrives from InputHub.</summary>
    public partial class EditorController : Node
    {
        public static EditorController I; public GageEntity Selected;
        MeshInstance3D marker; bool dragEntity, dragCam, moved; float markerSize = 2f;
        readonly Dictionary<int, Vector2> pts = new Dictionary<int, Vector2>();

        public override void _EnterTree() { I = this; }

        // ---------- picking (no physics engine: ray vs height field, ray vs boxes) ----------
        bool MakeRay(Vector2 screen, out Vector3 o, out Vector3 d)
        {
            o = d = Vector3.Zero; var sb = SceneBuilder.I; if (sb == null || sb.Cam == null || !sb.Cam.IsInsideTree()) return false;
            Vector2 s = InputHub.I.ToCam(screen);
            o = sb.Cam.ProjectRayOrigin(s); d = sb.Cam.ProjectRayNormal(s); return true;
        }

        public bool RayTerrain(Vector2 screen, out Vector3 p)
        {
            p = Vector3.Zero; Vector3 o, d; float dist;
            if (!MakeRay(screen, out o, out d)) return false;
            return SceneBuilder.I.Terrain.Raycast(o, d, 1000f, out p, out dist);
        }

        static bool RayBox(Vector3 o, Vector3 d, Aabb b, out float t)
        {
            t = 0f; float tmin = 0f, tmax = 1e9f; Vector3 mn = b.Position, mx = b.End;
            for (int a = 0; a < 3; a++)
            {
                float oa = a == 0 ? o.X : (a == 1 ? o.Y : o.Z), da = a == 0 ? d.X : (a == 1 ? d.Y : d.Z);
                float lo = a == 0 ? mn.X : (a == 1 ? mn.Y : mn.Z), hi = a == 0 ? mx.X : (a == 1 ? mx.Y : mx.Z);
                if (Mathf.Abs(da) < 1e-8f) { if (oa < lo || oa > hi) return false; continue; }
                float t1 = (lo - oa) / da, t2 = (hi - oa) / da; if (t1 > t2) { float x = t1; t1 = t2; t2 = x; }
                tmin = Mathf.Max(tmin, t1); tmax = Mathf.Min(tmax, t2); if (tmin > tmax) return false;
            }
            t = tmin; return true;
        }

        GageEntity PickEntity(Vector2 screen)
        {
            Vector3 o, d; if (!MakeRay(screen, out o, out d)) return null;
            var sb = SceneBuilder.I; float terrT = float.MaxValue; Vector3 hp; float td;
            if (sb.Terrain.Raycast(o, d, 1000f, out hp, out td)) terrT = td;
            GageEntity best = null; float bt = float.MaxValue;
            foreach (var ge in sb.Entities)
            {
                if (ge == null || !GodotObject.IsInstanceValid(ge) || !ge.Visible) continue;
                Aabb box; if (!ge.WorldBounds(out box)) continue; float t;
                if (RayBox(o, d, box.Grow(0.15f), out t) && t < bt) { bt = t; best = ge; }
            }
            return bt < terrT ? best : null;
        }

        public void Select(GageEntity ge)
        {
            Selected = ge; if (ge == null) return;
            Aabb b; markerSize = ge.WorldBounds(out b) ? Mathf.Clamp(Mathf.Max(b.Size.X, b.Size.Z), 1f, 12f) : 2f;
        }
        public void RotateSel(float deg) { if (Selected != null) Selected.RotateY(Mathf.DegToRad(deg)); }
        public void ScaleSel(float f)
        {
            if (Selected == null) return; float cur = Selected.Scale.X, s = Mathf.Clamp(cur * f, 0.3f, 6f);
            markerSize *= s / cur; Selected.Scale = Vector3.One * s;
        }
        public void DeleteSel() { if (Selected == null) return; SceneBuilder.I.RemoveEntity(Selected); Selected = null; }
        public void DuplicateSel() { if (Selected == null) return; var d = SceneBuilder.I.Duplicate(Selected); if (d != null) Select(d); }

        // ---------- pointer input ----------
        public void PointerDown(int id, Vector2 pos)
        {
            var sb = SceneBuilder.I; if (sb == null || sb.Playing) return;
            pts[id] = pos;
            if (pts.Count >= 2) { dragEntity = dragCam = false; return; }
            moved = false; var ent = PickEntity(pos);
            if (ent != null) { Select(ent); dragEntity = true; dragCam = false; } else { dragCam = true; dragEntity = false; }
        }

        public void PointerMove(int id, Vector2 pos, Vector2 rel)
        {
            var sb = SceneBuilder.I; if (sb == null || sb.Playing || !pts.ContainsKey(id)) return;
            if (pts.Count >= 2)
            {
                // pinch zoom + two-finger pan
                int other = -1; foreach (var k in pts.Keys) if (k != id) { other = k; break; }
                if (other >= 0)
                {
                    float prev = (pts[id] - pts[other]).Length(), now = (pos - pts[other]).Length();
                    sb.Cam.Zoom((now - prev) * 0.004f); sb.Cam.Pan(rel * 0.5f);
                }
                pts[id] = pos; return;
            }
            pts[id] = pos;
            if (dragEntity && Selected != null)
            {
                Vector3 p;
                if (RayTerrain(pos, out p))
                {
                    float h = sb.Terrain.Size * 0.5f - 2f; p.X = Mathf.Clamp(p.X, -h, h); p.Z = Mathf.Clamp(p.Z, -h, h);
                    Selected.Position = new Vector3(p.X, sb.Terrain.HeightAt(p.X, p.Z) + Selected.data.y, p.Z);
                }
            }
            else if (dragCam) { if (rel.Length() > 1f) moved = true; sb.Cam.Orbit(rel); }
        }

        public void PointerUp(int id)
        {
            if (!pts.ContainsKey(id)) return;
            bool single = pts.Count == 1; pts.Remove(id);
            if (single && dragCam && !moved) Select(null);
            if (pts.Count == 0) dragEntity = dragCam = false;
            if (single && dragEntity) SceneBuilder.I.Capture();
        }

        public override void _Process(double delta)
        {
            var sb = SceneBuilder.I;
            if (sb == null || sb.Terrain == null || sb.Playing || Selected == null || !GodotObject.IsInstanceValid(Selected)) { if (marker != null) marker.Visible = false; return; }
            if (marker == null)
            {
                var m = MaterialFactory.Make(new Color(1f, .85f, .1f, .45f), .1f, 0f, true, new Color(.6f, .5f, 0f));
                m.ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded;
                marker = new MeshInstance3D { Name = "SelectionMarker", Mesh = new CylinderMesh { TopRadius = 0.5f, BottomRadius = 0.5f, Height = 1f, RadialSegments = 32 }, MaterialOverride = m };
                marker.CastShadow = GeometryInstance3D.ShadowCastingSetting.Off; sb.AddChild(marker);
            }
            marker.Visible = true; marker.GlobalPosition = Selected.GlobalPosition + Vector3.Up * 0.08f;
            marker.Scale = new Vector3(markerSize * 1.25f, 0.02f, markerSize * 1.25f);
        }
    }
}
