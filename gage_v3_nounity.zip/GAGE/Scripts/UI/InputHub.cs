using System;
using System.Collections.Generic;
using Godot;

namespace GAGE
{
    /// <summary>
    /// One place for touch + mouse + keyboard. Decides what every finger does: UI, virtual joystick, camera look, or editor.
    /// UI buttons keep working through Godot's own emulated mouse; this hub ignores those emulated events (Device == -1).
    /// </summary>
    public partial class InputHub : Node
    {
        public static InputHub I;
        public Vector2 Move;                         // virtual joystick, y = forward
        public Func<Rect2> JoyRect;                  // set by EditorUI
        public readonly List<Control> Blockers = new List<Control>();   // visible panels/buttons swallow touches
        public string PaletteType;                   // set by a palette button on ButtonDown

        class Ptr { public Vector2 pos; public bool ui, joy, look, moved, edit; public Vector2 start; }
        readonly Dictionary<int, Ptr> ptrs = new Dictionary<int, Ptr>();
        const int MouseId = 1000;
        bool jump, rmb, mmb, lmb, palDragged; Node3D ghost; string ghostType;

        public override void _EnterTree() { I = this; }

        public void QueueJump() { jump = true; }
        public bool TakeJump() { bool j = jump; jump = false; return j; }
        public bool ConsumePalDragged() { bool d = palDragged; palDragged = false; return d; }

        public Vector2 KeyMove()
        {
            if (TextFocused()) return Vector2.Zero;
            float x = 0, y = 0;
            if (Input.IsKeyPressed(Key.D) || Input.IsKeyPressed(Key.Right)) x += 1;
            if (Input.IsKeyPressed(Key.A) || Input.IsKeyPressed(Key.Left)) x -= 1;
            if (Input.IsKeyPressed(Key.W) || Input.IsKeyPressed(Key.Up)) y += 1;
            if (Input.IsKeyPressed(Key.S) || Input.IsKeyPressed(Key.Down)) y -= 1;
            return new Vector2(x, y);
        }

        bool TextFocused()
        {
            var f = GetViewport().GuiGetFocusOwner();
            return f is LineEdit || f is TextEdit;
        }

        public bool IsOverUI(Vector2 pos)
        {
            foreach (var c in Blockers)
                if (c != null && GodotObject.IsInstanceValid(c) && c.IsVisibleInTree() && c.GetGlobalRect().HasPoint(pos)) return true;
            return false;
        }

        /// <summary>Converts a canvas/UI-space point to the pixel space Camera3D projection expects (they differ under stretch mode).</summary>
        public Vector2 ToCam(Vector2 p)
        {
            var vp = GetViewport(); Vector2 vis = vp.GetVisibleRect().Size; Vector2 real = new Vector2(GetWindow().Size.X, GetWindow().Size.Y);
            if (vis.X < 1f || vis.Y < 1f) return p; return new Vector2(p.X * real.X / vis.X, p.Y * real.Y / vis.Y);
        }

        public override void _Input(InputEvent ev)
        {
            var sb = SceneBuilder.I; if (sb == null || sb.Terrain == null) return;
            var st = ev as InputEventScreenTouch;
            if (st != null) { if (st.Pressed) Down(st.Index, st.Position); else Up(st.Index); return; }
            var sd = ev as InputEventScreenDrag;
            if (sd != null) { Drag(sd.Index, sd.Position, sd.Relative); return; }

            var mb = ev as InputEventMouseButton;
            if (mb != null)
            {
                if (mb.Device == -1) return;                         // emulated from touch: the touch event above already handled it
                if (mb.ButtonIndex == MouseButton.WheelUp || mb.ButtonIndex == MouseButton.WheelDown)
                {
                    if (mb.Pressed && !IsOverUI(mb.Position)) sb.Cam.Zoom(mb.ButtonIndex == MouseButton.WheelUp ? 0.1f : -0.1f);
                    return;
                }
                if (mb.ButtonIndex == MouseButton.Right) rmb = mb.Pressed;
                else if (mb.ButtonIndex == MouseButton.Middle) mmb = mb.Pressed;
                else if (mb.ButtonIndex == MouseButton.Left) { lmb = mb.Pressed; if (mb.Pressed) Down(MouseId, mb.Position); else Up(MouseId); }
                return;
            }
            var mm = ev as InputEventMouseMotion;
            if (mm != null)
            {
                if (mm.Device == -1) return;
                if (rmb && !IsOverUI(mm.Position)) sb.Cam.Orbit(mm.Relative * 0.8f);
                else if (mmb && !sb.Playing) sb.Cam.Pan(mm.Relative * 2f);
                else if (lmb) Drag(MouseId, mm.Position, mm.Relative);
                return;
            }
            var key = ev as InputEventKey;
            if (key != null && key.Pressed && !key.Echo && key.Keycode == Key.Space && !TextFocused()) jump = true;
        }

        // ---------- pointers ----------
        void Down(int id, Vector2 pos)
        {
            var sb = SceneBuilder.I; var p = new Ptr { pos = pos, start = pos }; ptrs[id] = p;
            if (IsOverUI(pos)) { p.ui = true; return; }
            GetViewport().GuiReleaseFocus();                          // leave any text box
            if (sb.Playing)
            {
                if (JoyRect != null && Move == Vector2.Zero && JoyRect().Grow(40f).HasPoint(pos) && !HasJoy()) { p.joy = true; UpdateJoy(pos); }
                else if (pos.X > GetViewport().GetVisibleRect().Size.X * 0.3f) p.look = true;
            }
            else { p.edit = true; EditorController.I.PointerDown(id, pos); }
        }

        bool HasJoy() { foreach (var kv in ptrs) if (kv.Value.joy) return true; return false; }

        void Drag(int id, Vector2 pos, Vector2 rel)
        {
            Ptr p; if (!ptrs.TryGetValue(id, out p)) return;
            var sb = SceneBuilder.I; p.pos = pos; if ((pos - p.start).Length() > 8f) p.moved = true;
            if (p.ui)
            {
                if (PaletteType != null && !sb.Playing && p.moved) PaletteDrag(pos);
                return;
            }
            if (p.joy) UpdateJoy(pos);
            else if (p.look) sb.Cam.Orbit(rel);
            else if (p.edit) EditorController.I.PointerMove(id, pos, rel);
        }

        void Up(int id)
        {
            Ptr p; if (!ptrs.TryGetValue(id, out p)) return; ptrs.Remove(id);
            if (p.ui) { PaletteDrop(p.pos); PaletteType = null; return; }
            if (p.joy) Move = Vector2.Zero;
            else if (p.edit) EditorController.I.PointerUp(id);
        }

        void UpdateJoy(Vector2 pos)
        {
            if (JoyRect == null) return; var r = JoyRect(); Vector2 c = r.GetCenter(); float R = r.Size.X * 0.5f;
            Vector2 v = new Vector2((pos.X - c.X) / R, -(pos.Y - c.Y) / R);
            Move = v.Length() > 1f ? v.Normalized() : v;
        }

        // ---------- drag an object from the palette into the world ----------
        void PaletteDrag(Vector2 pos)
        {
            palDragged = true; var sb = SceneBuilder.I;
            if (ghost == null || ghostType != PaletteType)
            {
                if (ghost != null) ghost.QueueFree();
                ghostType = PaletteType; ghost = PropFactory.Create(EntityTypes.Make(PaletteType, 0, 0), false);
                sb.WorldRoot.AddChild(ghost); ghost.Visible = false;
            }
            Vector3 hit;
            if (!IsOverUI(pos) && EditorController.I.RayTerrain(pos, out hit)) { ghost.Visible = true; ghost.GlobalPosition = hit + Vector3.Up * EntityTypes.DefaultY(ghostType); }
            else ghost.Visible = false;
        }

        void PaletteDrop(Vector2 pos)
        {
            if (ghost == null) return;
            bool shown = ghost.Visible; Vector3 hit = ghost.GlobalPosition; string t = ghostType;
            ghost.QueueFree(); ghost = null; ghostType = null;
            if (shown) { var ge = SceneBuilder.I.AddEntity(t, hit); EditorController.I.Select(ge); }
        }
    }
}
