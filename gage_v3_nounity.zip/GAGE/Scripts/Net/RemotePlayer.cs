using Godot;

namespace GAGE
{
    /// <summary>Visual copy of another online player. Smoothly follows the last position received from the server.</summary>
    public partial class RemotePlayer : Node3D
    {
        public bool Live; Vector3 target; float targetRy; bool first = true; Label3D label;

        public static RemotePlayer Create(MpPlayerInfo info)
        {
            var rp = new RemotePlayer { Name = "Remote " + info.name };
            var model = PropFactory.CreatePlayer();
            foreach (Node c in model.GetChildren()) { model.RemoveChild(c); rp.AddChild(c); }
            model.QueueFree();
            // each player gets a stable colour so everybody sees the same one
            float hue = (MultiplayerClient.StableHash(info.id) % 360) / 360f;
            var body = rp.GetChildOrNull<MeshInstance3D>(0);
            if (body != null) { var m = MaterialFactory.Make(Color.FromHsv(hue, .65f, .95f), .35f); body.MaterialOverride = m; }
            rp.label = new Label3D { Text = info.name, Billboard = BaseMaterial3D.BillboardModeEnum.Enabled, PixelSize = 0.01f, FontSize = 48, OutlineSize = 12, NoDepthTest = true };
            rp.AddChild(rp.label); rp.label.Position = new Vector3(0, 2.5f, 0);
            return rp;
        }

        public void SetTarget(Vector3 pos, float ryDeg, string name)
        {
            target = pos; targetRy = Mathf.DegToRad(ryDeg); if (label != null && label.Text != name) label.Text = name;
            if (first) { Position = pos; Rotation = new Vector3(0, targetRy, 0); first = false; }
        }

        public override void _Process(double delta)
        {
            float k = 1f - Mathf.Exp(-14f * (float)delta);
            Position = Position.Lerp(target, k);
            Rotation = new Vector3(0, Mathf.LerpAngle(Rotation.Y, targetRy, k), 0);
        }
    }
}
