using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Godot;

namespace GAGE
{
    // ---- wire format (matches Server/multiplayer.js) ----
    public class MpPlayerInfo { public string id = ""; public string name = ""; public float x, y, z, ry; public int score; public bool host, pl; }
    public class MpCoin { public int c; public int p; public string by = ""; }
    public class MpClaim { public int c; public int p; }
    class MpSyncReq { public string room, id, token; public float x, y, z, ry; public bool pl; public MpClaim[] claim; }
    class MpIdReq { public string room, id, token; }
    class MpJoinReq { public string room, name; }
    class MpHostReq { public string name; public SceneData scene; }
    class MpResp
    {
        public string error = "", room = "", id = "", token = "";
        public SceneData scene;
        public MpPlayerInfo[] players; public MpCoin[] taken; public int score, team;
    }

    /// <summary>
    /// Online co-op over plain HTTPS (~10 syncs/sec). Host uploads the scene, friends join with a 4-letter code,
    /// everybody sees each other and the coins are shared: first to touch a coin gets it, the score is the TEAM score.
    /// Enemies run locally on each device (not synced).
    /// </summary>
    public partial class MultiplayerClient : Node
    {
        public static MultiplayerClient I;
        public static readonly Dictionary<int, Collectible3D> Coins = new Dictionary<int, Collectible3D>();
        static readonly System.Net.Http.HttpClient Http = new System.Net.Http.HttpClient { Timeout = TimeSpan.FromSeconds(20) };

        public bool Joined { get { return !string.IsNullOrEmpty(token); } }
        public string Room = "", MyId = "", Status = "", PlayerName = "Player";
        public bool IsHost; public int MyScore;
        public readonly List<MpPlayerInfo> Others = new List<MpPlayerInfo>();

        string token = ""; bool busy; int loopGen;
        readonly List<MpClaim> pending = new List<MpClaim>();
        readonly Dictionary<string, RemotePlayer> remotes = new Dictionary<string, RemotePlayer>();

        public override void _EnterTree()
        {
            I = this;
            PlayerName = "Player" + U.Rng.Next(100, 999);
            try { var cf = new ConfigFile(); if (cf.Load("user://prefs.cfg") == Error.Ok) { string n = cf.GetValue("gage", "name", "").AsString(); if (n.Length > 0) PlayerName = n; } } catch (Exception) { }
        }
        public override void _Notification(int what) { if (what == (int)NotificationWMCloseRequest && Joined) { var _ = LeaveRoutine(); } }

        // ---------- server address ----------
        public static string Base
        {
            get
            {
                string mp = GAGEConfig.MpEndpoint; if (!string.IsNullOrEmpty(mp)) return mp.EndsWith("/") ? mp : mp + "/";
                string ep = GAGEConfig.Endpoint; if (string.IsNullOrEmpty(ep)) return "";
                int i = ep.IndexOf("/api/"); if (i > 0) return ep.Substring(0, i) + "/mp/";
                return ep.TrimEnd('/') + "/mp/";
            }
        }
        public static bool Available { get { return !string.IsNullOrEmpty(Base); } }
        public static int StableHash(string s) { int h = 17; foreach (char c in s ?? "") h = unchecked(h * 31 + c); return h & 0x7fffffff; }

        // ---------- public API (called from the UI) ----------
        public void SetName(string n)
        {
            n = (n ?? "").Trim(); if (n.Length == 0) return; PlayerName = n.Length > 16 ? n.Substring(0, 16) : n;
            try { var cf = new ConfigFile(); cf.SetValue("gage", "name", PlayerName); cf.Save("user://prefs.cfg"); } catch (Exception) { }
        }

        public async void Host()
        {
            if (busy || Joined) return;
            if (!Available) { Status = "Multiplayer ke liye gage_config.json me server endpoint chahiye."; return; }
            if (SceneBuilder.I.Playing && !GameBundle.Exists) { Status = "Pehle STOP dabao, phir host karo."; return; }
            if (!SceneBuilder.I.Playing) SceneBuilder.I.Capture();
            Status = "Room ban raha hai...";
            var r = await Post("host", new MpHostReq { name = PlayerName, scene = SceneBuilder.I.Data });
            OnEntered(r, true);
        }

        public async void Join(string room)
        {
            if (busy || Joined) return; room = (room ?? "").Trim().ToUpperInvariant();
            if (room.Length != 4) { Status = "4 akshar ka room code likho."; return; }
            if (!Available) { Status = "Multiplayer ke liye gage_config.json me server endpoint chahiye."; return; }
            if (SceneBuilder.I.Playing && !GameBundle.Exists) { Status = "Pehle STOP dabao, phir join karo."; return; }
            Status = "Join ho raha hai...";
            var r = await Post("join", new MpJoinReq { room = room, name = PlayerName });
            OnEntered(r, false);
        }

        public async void Leave() { if (Joined) await LeaveRoutine(); }

        void OnEntered(MpResp r, bool host)
        {
            if (!string.IsNullOrEmpty(r.error)) { Status = "Error: " + r.error; return; }
            token = r.token; MyId = r.id; Room = r.room; IsHost = host; MyScore = 0; Others.Clear(); pending.Clear();
            if (!host && r.scene != null && r.scene.entities != null) { SceneBuilder.I.Load(r.scene); if (GameBundle.Exists) SceneBuilder.I.SetPlaying(true); }
            Status = host ? "Room " + Room + " ready. Dosto ko ye code do, phir sab PLAY dabao." : "Room " + Room + " join hua. PLAY dabao.";
            SyncLoop(++loopGen);
        }

        async Task LeaveRoutine()
        {
            var body = new MpIdReq { room = Room, id = MyId, token = token };
            ResetState(); Status = "Room chhod diya.";
            await Post("leave", body);
        }

        void ResetState()
        {
            token = ""; Room = ""; MyId = ""; IsHost = false; Others.Clear(); pending.Clear(); loopGen++;
            foreach (var kv in remotes) if (kv.Value != null && GodotObject.IsInstanceValid(kv.Value)) kv.Value.QueueFree();
            remotes.Clear();
        }

        /// <summary>Called by a coin the local player just touched.</summary>
        public void Claim(int netId, int points) { if (Joined && netId >= 0) pending.Add(new MpClaim { c = netId, p = points }); }

        // ---------- sync ----------
        async void SyncLoop(int gen)
        {
            int fails = 0;
            while (Joined && gen == loopGen)
            {
                var sb = SceneBuilder.I; var req = new MpSyncReq { room = Room, id = MyId, token = token };
                if (sb != null && sb.Playing && sb.Player != null)
                {
                    var p = sb.Player.GlobalPosition; req.x = p.X; req.y = p.Y; req.z = p.Z; req.ry = Mathf.RadToDeg(sb.Player.Rotation.Y); req.pl = true;
                }
                int sent = pending.Count; req.claim = pending.ToArray();
                var resp = await Post("sync", req);
                if (!Joined || gen != loopGen) return;
                if (string.IsNullOrEmpty(resp.error))
                {
                    fails = 0; pending.RemoveRange(0, Math.Min(sent, pending.Count)); Apply(resp);
                }
                else
                {
                    fails++; string e = resp.error;
                    if (e == "room not found" || e == "bad player token") { ResetState(); Status = "Room band ho gaya / server restart hua. Dobara host/join karo."; return; }
                    Status = "Connection problem (" + fails + ")";
                    if (fails > 40) { ResetState(); Status = "Connection toot gaya."; return; }
                    await Task.Delay(400); continue;
                }
                await Task.Delay(100);
            }
        }

        void Apply(MpResp r)
        {
            MyScore = r.score; Others.Clear();
            var gs = GameSession.I; var alive = new HashSet<string>();
            if (r.players != null)
                foreach (var p in r.players)
                {
                    Others.Add(p); alive.Add(p.id);
                    RemotePlayer rp;
                    if (!remotes.TryGetValue(p.id, out rp) || rp == null || !GodotObject.IsInstanceValid(rp)) { rp = RemotePlayer.Create(p); SceneBuilder.I.AddChild(rp); remotes[p.id] = rp; }
                    rp.SetTarget(new Vector3(p.x, p.y, p.z), p.ry, p.name); rp.Live = p.pl;
                }
            var gone = new List<string>(); foreach (var k in remotes.Keys) if (!alive.Contains(k)) gone.Add(k);
            foreach (var k in gone) { if (remotes[k] != null && GodotObject.IsInstanceValid(remotes[k])) remotes[k].QueueFree(); remotes.Remove(k); }

            // coins somebody else took: remove them here and credit the team score once
            if (r.taken != null && gs != null)
                foreach (var t in r.taken)
                {
                    Collectible3D coin;
                    if (Coins.TryGetValue(t.c, out coin) && coin != null && GodotObject.IsInstanceValid(coin)) { Coins.Remove(t.c); coin.Take(); gs.AddScore(Mathf.Max(1, t.p)); }
                }
        }

        public override void _Process(double delta)
        {
            bool play = SceneBuilder.I != null && SceneBuilder.I.Playing;
            foreach (var kv in remotes)
            {
                if (kv.Value == null || !GodotObject.IsInstanceValid(kv.Value)) continue;
                bool show = play && kv.Value.Live; if (kv.Value.Visible != show) kv.Value.Visible = show;
            }
        }

        public Vector3 SpawnOffset()
        {
            if (!Joined) return Vector3.Zero;
            float a = Mathf.DegToRad((StableHash(MyId) % 8) * 45f); return new Vector3(Mathf.Cos(a), 0, Mathf.Sin(a)) * 2.2f;
        }

        // ---------- http ----------
        async Task<MpResp> Post(string path, object bodyObj)
        {
            bool isSync = path == "sync"; if (!isSync) busy = true;
            MpResp r = null;
            try
            {
                using (var req = new HttpRequestMessage(HttpMethod.Post, Base + path))
                {
                    req.Content = new StringContent(GJson.To(bodyObj), Encoding.UTF8, "application/json");
                    if (!string.IsNullOrEmpty(GAGEConfig.AccessToken)) req.Headers.TryAddWithoutValidation("X-GAGE-Access", GAGEConfig.AccessToken);
                    using (var cts = new System.Threading.CancellationTokenSource(TimeSpan.FromSeconds(isSync ? 6 : 20)))
                    using (var resp = await Http.SendAsync(req, cts.Token))
                    {
                        string txt = await resp.Content.ReadAsStringAsync();
                        if (!string.IsNullOrEmpty(txt)) { try { r = GJson.From<MpResp>(txt); } catch (Exception) { r = null; } }
                        if (r == null) r = new MpResp();
                        if (!resp.IsSuccessStatusCode && string.IsNullOrEmpty(r.error)) r.error = "HTTP " + (int)resp.StatusCode;
                    }
                }
            }
            catch (Exception e) { if (r == null) r = new MpResp(); if (string.IsNullOrEmpty(r.error)) r.error = string.IsNullOrEmpty(e.Message) ? "network error" : e.Message; }
            if (!isSync) busy = false;
            return r;
        }
    }
}
