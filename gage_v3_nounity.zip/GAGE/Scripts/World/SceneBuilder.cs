using System.Collections.Generic;
using Godot;

namespace GAGE
{
    /// <summary>Owns the world: builds terrain/sky, spawns entities, runs Edit/Play modes, applies AI operations.</summary>
    public partial class SceneBuilder : Node
    {
        public static SceneBuilder I;
        public SceneData Data = new SceneData();
        public TerrainInfo Terrain; public NavGrid Nav;
        public GameCamera Cam; public DirectionalLight3D Sun;
        public PlayerController3D Player; public bool Playing;
        public readonly List<GageEntity> Entities = new List<GageEntity>();
        public readonly List<Vector3> Obstacles = new List<Vector3>();   // x, z, radius (for the player)
        public Node3D WorldRoot, EntRoot;
        MeshInstance3D terrainMI, waterMI; Godot.Environment env; ProceduralSkyMaterial skyMat;
        const int MaxEntities = 450;

        public override void _EnterTree() { I = this; }

        public override void _Ready()
        {
            WorldRoot = new Node3D { Name = "World" }; AddChild(WorldRoot);
            EntRoot = new Node3D { Name = "Entities" }; AddChild(EntRoot);
            Sun = new DirectionalLight3D { Name = "Sun" }; AddChild(Sun);
            skyMat = new ProceduralSkyMaterial();
            env = new Godot.Environment { Sky = new Sky { SkyMaterial = skyMat } };
            AddChild(new WorldEnvironment { Name = "Environment", Environment = env });
            Cam = new GameCamera { Name = "GAGE Camera", Near = 0.2f, Far = 600f, Fov = 60f };
            AddChild(Cam); Cam.MakeCurrent();
        }

        // ---------- loading ----------
        public void Load(SceneData d)
        {
            Playing = false; GameSession.I.End(); Data = d; BuildWorld(); RebuildEntities(false); Cam.SetEditMode(Vector3.Zero, true);
        }

        public void LoadGame(AIGame g)
        {
            var d = new SceneData { world = g.world ?? new WorldData(), player = g.player ?? new PlayerData(), targetScore = g.targetScore, winText = g.winText, loseText = g.loseText };
            d.player.speed = Mathf.Clamp(d.player.speed, 3f, 10f); d.player.health = Mathf.Clamp(d.player.health, 1, 12);
            Playing = false; GameSession.I.End(); Data = d; BuildWorld(); RebuildEntities(false);
            ApplyOpList(g.ops); Cam.SetEditMode(Vector3.Zero, true);
        }

        public void BuildWorld()
        {
            if (terrainMI != null) terrainMI.QueueFree();
            if (waterMI != null) waterMI.QueueFree();
            Terrain = TerrainBuilder.Build(Data.world, WorldRoot, out terrainMI, out waterMI);
            SkyLight.Apply(Data.world, Sun, env, skyMat);
            RenderBoost.ApplyQuality(GetViewport());
        }

        public void RebuildEntities(bool play)
        {
            foreach (Node c in EntRoot.GetChildren()) { EntRoot.RemoveChild(c); c.QueueFree(); }
            if (Player != null) { Player.QueueFree(); Player = null; }
            Entities.Clear();
            foreach (var e in Data.entities) SpawnEntity(e, play);
            RebuildNav();
            if (play) SpawnPlayer();
        }

        void RebuildNav()
        {
            Nav = NavGrid.Build(Terrain, Entities);
            Obstacles.Clear();
            foreach (var ge in Entities)
            {
                if (ge == null || !GodotObject.IsInstanceValid(ge)) continue;
                float r = EntityTypes.ObstacleRadius(ge.data.type); if (r <= 0f) continue;
                Obstacles.Add(new Vector3(ge.Position.X, ge.Position.Z, r * ge.data.scale));
            }
        }

        GageEntity SpawnEntity(EntityData e, bool play)
        {
            var ge = PropFactory.Create(e, play); EntRoot.AddChild(ge); Place(ge, e);
            var coin = ge.GetNodeOrNull<Collectible3D>("Collectible"); if (coin != null) coin.netId = Data.entities.IndexOf(e);   // same index on every device = shared coin id
            if (play && e.type == "spawn") ge.Visible = false;
            Entities.Add(ge); return ge;
        }

        void Place(Node3D go, EntityData e)
        {
            go.Position = new Vector3(e.x, Terrain.HeightAt(e.x, e.z) + e.y, e.z);
            go.RotationDegrees = new Vector3(0, e.rotY, 0); go.Scale = Vector3.One * e.scale;
        }
        public void RepositionAll() { foreach (var ge in Entities) if (ge != null && GodotObject.IsInstanceValid(ge)) Place(ge, ge.data); }

        void SpawnPlayer()
        {
            Vector3 p = Vector3.Zero;
            foreach (var ge in Entities) if (ge.data.type == "spawn") { p = new Vector3(ge.data.x, 0, ge.data.z); break; }
            if (MultiplayerClient.I != null) { var off = MultiplayerClient.I.SpawnOffset(); p.X += off.X; p.Z += off.Z; }   // online players do not stack
            var model = PropFactory.CreatePlayer();
            Player = new PlayerController3D { Name = "PlayerController", speed = Data.player.speed };
            EntRoot.AddChild(Player);
            foreach (Node c in model.GetChildren()) { model.RemoveChild(c); Player.AddChild(c); }
            model.QueueFree();
            Player.GlobalPosition = new Vector3(p.X, Terrain.HeightAt(p.X, p.Z) + 0.3f, p.Z);
            GameSession.I.Begin(Data);
            Cam.SetPlayMode(Player);
            if (ScriptHost.I != null) ScriptHost.I.Begin();
        }

        public void SetPlaying(bool play)
        {
            if (play == Playing) return;
            if (play) Capture();
            Playing = play; EditorController.I.Select(null);
            if (play) RebuildEntities(true); else { GameSession.I.End(); RebuildEntities(false); Cam.SetEditMode(Vector3.Zero, false); }
        }

        /// <summary>Write the live transforms back into Data (so Save and Play see what you dragged).</summary>
        public void Capture()
        {
            foreach (var ge in Entities)
            {
                if (ge == null || !GodotObject.IsInstanceValid(ge)) continue; var e = ge.data; var p = ge.Position;
                e.x = p.X; e.z = p.Z; e.y = p.Y - Terrain.HeightAt(p.X, p.Z); e.rotY = Mathf.RadToDeg(ge.Rotation.Y); e.scale = ge.Scale.X;
            }
        }

        // ---------- editing ----------
        public GageEntity AddEntity(string type, Vector3 point)
        {
            if (Entities.Count >= MaxEntities) return null;
            var e = EntityTypes.Make(type, point.X, point.Z); Data.entities.Add(e);
            var ge = SpawnEntity(e, false); RebuildNav(); return ge;
        }
        public GageEntity AddModel(string uid, Vector3 point)
        {
            if (Entities.Count >= MaxEntities) return null;
            var e = EntityTypes.Make("model", point.X, point.Z); e.text = uid; Data.entities.Add(e);
            var ge = SpawnEntity(e, false); RebuildNav(); return ge;
        }
        /// <summary>Spawn during Play (used by Lua scripts). Not saved into the scene data.</summary>
        public GageEntity SpawnLive(string type, float x, float z)
        {
            if (!EntityTypes.IsValid(type) || Entities.Count >= MaxEntities) return null;
            return SpawnEntity(EntityTypes.Make(type, x, z), true);
        }
        public void RemoveEntity(GageEntity ge)
        {
            if (ge == null) return; Entities.Remove(ge); Data.entities.Remove(ge.data); ge.QueueFree(); RebuildNav();
        }
        public GageEntity Duplicate(GageEntity src)
        {
            if (src == null || Entities.Count >= MaxEntities) return null;
            Capture(); var e = EntityTypes.Clone(src.data); e.x += 2.5f; e.z += 2.5f; Data.entities.Add(e);
            var ge = SpawnEntity(e, false); RebuildNav(); return ge;
        }

        // ---------- AI ops ----------
        public string ApplyOps(AIOps o)
        {
            if (o == null) return "";
            ApplyOpList(o.ops);
            return string.IsNullOrEmpty(o.reply) ? "Done." : o.reply;
        }

        public void ApplyOpList(AIOp[] ops)
        {
            if (ops == null) return; if (!Playing) Capture();
            int n = 0;
            foreach (var op in ops)
            {
                if (op == null || ++n > 40) continue;
                switch (op.op)
                {
                    case "add": OpAdd(op); break;
                    case "remove": OpRemove(op); break;
                    case "world": OpWorld(op.world); break;
                }
            }
            RebuildNav();
        }

        void OpAdd(AIOp op)
        {
            if (!EntityTypes.IsValid(op.type)) return;
            int count = Mathf.Clamp(op.count, 1, 200);
            float half = Terrain.Size * 0.5f - 4f;
            for (int i = 0; i < count && Entities.Count < MaxEntities; i++)
            {
                float x, z;
                if (op.exact) { x = op.cx; z = op.cz; }
                else if (!RandomPoint(op, half, out x, out z)) continue;
                var e = EntityTypes.Make(op.type, x, z);
                e.rotY = U.Rand(0f, 360f);
                float sc = op.scale <= 0 ? 1f : op.scale; e.scale = Mathf.Clamp(sc * (1f + U.Rand(-op.scaleVar, op.scaleVar)), 0.2f, 6f);
                if (op.type == "spawn") e.scale = 1f;
                if (!string.IsNullOrEmpty(op.color)) e.color = op.color;
                if (!string.IsNullOrEmpty(op.behavior)) e.behavior = op.behavior;
                if (op.speed > 0) e.speed = op.speed;
                if (op.points > 0) e.points = op.points;
                if (!string.IsNullOrEmpty(op.text)) e.text = op.text;
                Data.entities.Add(e); SpawnEntity(e, Playing);
            }
        }

        bool RandomPoint(AIOp op, float half, out float x, out float z)
        {
            x = z = 0;
            for (int t = 0; t < 40; t++)
            {
                if (op.radius > 0) { var c = U.RandInCircle(op.radius); x = op.cx + c.X; z = op.cz + c.Y; }
                else { x = U.Rand(-half, half); z = U.Rand(-half, half); }
                if (Mathf.Abs(x) > half || Mathf.Abs(z) > half) continue;
                if (Terrain.HeightAt(x, z) < Terrain.WaterLevel + 0.4f) continue;
                if (Terrain.Slope(x, z) > EntityTypes.MaxSlope(op.type)) continue;
                if (op.type == "enemy" && x * x + z * z < 14f * 14f) continue;
                if (op.type != "coin" && op.type != "spawn" && op.type != "npc" && x * x + z * z < 5f * 5f) continue;   // keep spawn clear
                return true;
            }
            return false;
        }

        void OpRemove(AIOp op)
        {
            for (int i = Entities.Count - 1; i >= 0; i--)
            {
                var ge = Entities[i]; if (ge == null || !GodotObject.IsInstanceValid(ge)) continue;
                if (op.type != "all" && ge.data.type != op.type) continue;
                if (ge.data.type == "spawn") continue;
                if (op.radius > 0) { float dx = ge.data.x - op.cx, dz = ge.data.z - op.cz; if (dx * dx + dz * dz > op.radius * op.radius) continue; }
                Entities.RemoveAt(i); Data.entities.Remove(ge.data); ge.QueueFree();
            }
        }

        void OpWorld(WorldPatch p)
        {
            if (p == null) return; var w = Data.world;
            if (!string.IsNullOrEmpty(p.title)) w.title = p.title;
            if (!string.IsNullOrEmpty(p.biome)) w.biome = p.biome;
            if (p.timeOfDay >= 0) w.timeOfDay = p.timeOfDay;
            if (p.fog >= 0) w.fog = p.fog;
            if (p.waterLevel > -900) w.waterLevel = p.waterLevel;
            if (p.heightScale > 0) w.heightScale = p.heightScale;
            if (p.size > 0) w.size = p.size;
            if (p.seed != 0) w.seed = p.seed;
            if (p.targetScore >= 0) Data.targetScore = p.targetScore;
            BuildWorld(); RepositionAll();
        }
    }
}
