using System.Collections.Generic;
using Godot;

namespace GAGE
{
    /// <summary>Walkability grid built from the terrain + obstacles. Paths come from C++ A* (or C# fallback).</summary>
    public class NavGrid
    {
        public int W; public float Cell, Half; byte[] blocked; TerrainInfo T;

        public static NavGrid Build(TerrainInfo t, List<GageEntity> ents)
        {
            var n = new NavGrid { T = t, W = Mathf.Clamp(Mathf.RoundToInt(t.Size / 1.5f), 40, 200) };
            n.Cell = t.Size / n.W; n.Half = t.Size * 0.5f; n.blocked = new byte[n.W * n.W];
            for (int z = 0; z < n.W; z++)
                for (int x = 0; x < n.W; x++)
                {
                    var p = n.CellToWorld(x, z);
                    if (p.Y < t.WaterLevel - 0.3f || t.Slope(p.X, p.Z) > 1.0f) n.blocked[z * n.W + x] = 1;
                }
            foreach (var e in ents)
            {
                if (e == null || !GodotObject.IsInstanceValid(e)) continue;
                float r = EntityTypes.ObstacleRadius(e.data.type);
                if (r <= 0) continue;
                r = r * e.data.scale + 0.4f;
                var pos = e.Position; int cr = Mathf.CeilToInt(r / n.Cell);
                int cx, cz; if (!n.WorldToCell(pos, out cx, out cz)) continue;
                for (int dz = -cr; dz <= cr; dz++)
                    for (int dx = -cr; dx <= cr; dx++)
                    {
                        int x = cx + dx, z = cz + dz; if (x < 0 || z < 0 || x >= n.W || z >= n.W) continue;
                        if (dx * dx + dz * dz <= cr * cr + 1) n.blocked[z * n.W + x] = 1;
                    }
            }
            return n;
        }

        public bool WorldToCell(Vector3 p, out int cx, out int cz)
        {
            cx = Mathf.FloorToInt((p.X + Half) / Cell); cz = Mathf.FloorToInt((p.Z + Half) / Cell);
            return cx >= 0 && cz >= 0 && cx < W && cz < W;
        }
        public Vector3 CellToWorld(int cx, int cz)
        {
            float x = -Half + (cx + 0.5f) * Cell, z = -Half + (cz + 0.5f) * Cell; return new Vector3(x, T.HeightAt(x, z), z);
        }

        bool Nearest(Vector3 p, out int ox, out int oz)
        {
            ox = oz = 0;
            int cx = Mathf.Clamp(Mathf.FloorToInt((p.X + Half) / Cell), 0, W - 1), cz = Mathf.Clamp(Mathf.FloorToInt((p.Z + Half) / Cell), 0, W - 1);
            for (int r = 0; r <= 8; r++)
                for (int dz = -r; dz <= r; dz++)
                    for (int dx = -r; dx <= r; dx++)
                    {
                        if (Mathf.Max(Mathf.Abs(dx), Mathf.Abs(dz)) != r) continue;
                        int x = cx + dx, z = cz + dz;
                        if (x >= 0 && z >= 0 && x < W && z < W && blocked[z * W + x] == 0) { ox = x; oz = z; return true; }
                    }
            return false;
        }

        public List<Vector3> FindPath(Vector3 from, Vector3 to)
        {
            int sx, sz, gx, gz; var list = new List<Vector3>();
            if (!Nearest(from, out sx, out sz) || !Nearest(to, out gx, out gz)) return list;
            var path = NativeBridge.AStar(blocked, W, W, sx, sz, gx, gz);
            if (path == null) return list;
            for (int i = 0; i < path.Length; i++) list.Add(CellToWorld(path[i] % W, path[i] / W));
            return list;
        }
    }
}
