using Godot;

namespace GAGE
{
    public class TerrainInfo
    {
        public float Size, HeightScale, WaterLevel; public int Res; public float[] H; // H normalized 0..1
        public float Cell { get { return Size / (Res - 1); } }
        public float HeightAt(float x, float z)
        {
            float fx = Mathf.Clamp((x + Size * 0.5f) / Cell, 0f, Res - 1.001f), fz = Mathf.Clamp((z + Size * 0.5f) / Cell, 0f, Res - 1.001f);
            int ix = (int)fx, iz = (int)fz; float tx = fx - ix, tz = fz - iz;
            float a = H[iz * Res + ix], b = H[iz * Res + ix + 1], c = H[(iz + 1) * Res + ix], d = H[(iz + 1) * Res + ix + 1];
            return U.Lerp(U.Lerp(a, b, tx), U.Lerp(c, d, tx), tz) * HeightScale;
        }
        public float Slope(float x, float z)
        {
            float e = Cell;
            float dx = HeightAt(x + e, z) - HeightAt(x - e, z), dz = HeightAt(x, z + e) - HeightAt(x, z - e);
            return Mathf.Sqrt(dx * dx + dz * dz) / (2f * e);
        }
        public bool Inside(float x, float z, float margin) { float h = Size * 0.5f - margin; return Mathf.Abs(x) < h && Mathf.Abs(z) < h; }

        /// <summary>First point where a ray hits the terrain surface (ray marching + bisection). No physics engine needed.</summary>
        public bool Raycast(Vector3 o, Vector3 d, float maxDist, out Vector3 hit, out float dist)
        {
            hit = Vector3.Zero; dist = 0f; float step = 0.6f, t = 0f; float prevT = 0f; bool prevAbove = o.Y > HeightAt(o.X, o.Z);
            for (; t < maxDist; t += step)
            {
                var p = o + d * t; float h = HeightAt(p.X, p.Z);
                bool above = p.Y > h;
                if (!above && prevAbove)
                {
                    float lo = prevT, hi = t;
                    for (int i = 0; i < 14; i++) { float mid = (lo + hi) * 0.5f; var q = o + d * mid; if (q.Y > HeightAt(q.X, q.Z)) lo = mid; else hi = mid; }
                    dist = hi; hit = o + d * hi; return true;
                }
                prevAbove = above; prevT = t;
                if (!Inside(p.X, p.Z, -60f) && p.Y < 0f) break;
            }
            return false;
        }
    }

    public static class TerrainBuilder
    {
        struct Pal { public Color sand, low, mid, high, rock; }
        static Pal GetPal(string biome)
        {
            switch (biome)
            {
                case "desert": return new Pal { sand = U.C(.86f, .74f, .5f), low = U.C(.82f, .67f, .42f), mid = U.C(.76f, .58f, .35f), high = U.C(.66f, .45f, .3f), rock = U.C(.5f, .33f, .25f) };
                case "snow": return new Pal { sand = U.C(.7f, .72f, .75f), low = U.C(.82f, .86f, .9f), mid = U.C(.92f, .94f, .97f), high = U.C(1f, 1f, 1f), rock = U.C(.45f, .47f, .5f) };
                case "volcanic": return new Pal { sand = U.C(.15f, .13f, .12f), low = U.C(.2f, .17f, .15f), mid = U.C(.26f, .2f, .17f), high = U.C(.35f, .25f, .2f), rock = U.C(.1f, .09f, .09f) };
                case "forest": return new Pal { sand = U.C(.5f, .46f, .3f), low = U.C(.12f, .32f, .1f), mid = U.C(.16f, .4f, .12f), high = U.C(.28f, .36f, .2f), rock = U.C(.36f, .34f, .3f) };
                default: return new Pal { sand = U.C(.76f, .7f, .5f), low = U.C(.25f, .46f, .15f), mid = U.C(.34f, .54f, .2f), high = U.C(.46f, .43f, .3f), rock = U.C(.42f, .4f, .37f) };
            }
        }

        const string TerrainShader = @"
shader_type spatial;
render_mode cull_disabled;
uniform sampler2D base_tex : source_color, filter_linear_mipmap_anisotropic, repeat_disable;
uniform sampler2D detail_albedo : source_color, filter_linear_mipmap_anisotropic, repeat_enable;
uniform sampler2D detail_normal : hint_normal, filter_linear_mipmap_anisotropic, repeat_enable;
uniform float tile = 40.0;
uniform float normal_depth = 0.9;
void fragment() {
    vec3 b = texture(base_tex, UV).rgb;
    float d1 = texture(detail_albedo, UV * tile).r;
    float d2 = texture(detail_albedo, UV * tile * 0.23).r;
    ALBEDO = b * clamp(d1 * d2 * 1.05, 0.0, 1.6);
    NORMAL_MAP = texture(detail_normal, UV * tile).rgb;
    NORMAL_MAP_DEPTH = normal_depth;
    ROUGHNESS = 0.93;
    SPECULAR = 0.25;
}";

        const string WaterShader = @"
shader_type spatial;
render_mode cull_disabled, specular_schlick_ggx;
uniform vec4 col : source_color = vec4(0.08, 0.3, 0.42, 0.72);
uniform sampler2D nrm : hint_normal, repeat_enable, filter_linear_mipmap;
uniform float tile = 60.0;
void fragment() {
    vec2 uv = UV * tile;
    vec3 n1 = texture(nrm, uv + TIME * vec2(0.020, 0.010)).rgb;
    vec3 n2 = texture(nrm, uv * 1.7 - TIME * vec2(0.015, 0.020)).rgb;
    NORMAL_MAP = mix(n1, n2, 0.5);
    NORMAL_MAP_DEPTH = 0.55;
    float fres = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 3.0);
    ALBEDO = col.rgb;
    ALPHA = clamp(col.a + fres * 0.25, 0.0, 1.0);
    ROUGHNESS = 0.04;
    METALLIC = 0.0;
    SPECULAR = 0.9;
}";
        static Shader terrainSh, waterSh;

        public static TerrainInfo Build(WorldData w, Node3D parent, out MeshInstance3D terrainMI, out MeshInstance3D waterMI)
        {
            w.size = Mathf.Clamp(w.size, 40f, 300f); w.heightScale = Mathf.Clamp(w.heightScale, 2f, 60f);
            int res = 161;
            float biomeRidge = (w.biome == "volcanic" || w.biome == "snow") ? 0.5f : (w.biome == "desert" ? 0.15f : 0.2f);
            float exp = w.biome == "desert" ? 1.2f : 1.5f;
            var h = NativeBridge.Heightmap(res, res, 2.5f + w.roughness * 3.5f, w.seed, 5, 0.42f + w.roughness * 0.2f, biomeRidge);
            float spawnH = U.Clamp01(w.waterLevel / w.heightScale + 0.1f);
            for (int z = 0; z < res; z++)
                for (int x = 0; x < res; x++)
                {
                    float v = Mathf.Pow(h[z * res + x], exp);
                    float dx = x / (float)(res - 1) - 0.5f, dz = z / (float)(res - 1) - 0.5f;
                    float d = Mathf.Sqrt(dx * dx + dz * dz) * 2f;                 // 0 center .. ~1.4 corner
                    float flat = U.Smooth(U.InvLerp(0.05f, 0.35f, d));
                    h[z * res + x] = U.Lerp(spawnH, v, flat);
                }
            var info = new TerrainInfo { Size = w.size, Res = res, H = h, HeightScale = w.heightScale, WaterLevel = w.waterLevel };

            // ---- mesh (SurfaceTool computes tangents for the normal map) ----
            float cell = info.Cell, hs = w.heightScale;
            var st = new SurfaceTool(); st.Begin(Mesh.PrimitiveType.Triangles);
            for (int z = 0; z < res; z++)
                for (int x = 0; x < res; x++)
                {
                    int i = z * res + x;
                    int x0 = Mathf.Max(x - 1, 0), x1 = Mathf.Min(x + 1, res - 1), z0 = Mathf.Max(z - 1, 0), z1 = Mathf.Min(z + 1, res - 1);
                    float dhx = (h[z * res + x1] - h[z * res + x0]) * hs / ((x1 - x0) * cell);
                    float dhz = (h[z1 * res + x] - h[z0 * res + x]) * hs / ((z1 - z0) * cell);
                    st.SetNormal(new Vector3(-dhx, 1f, -dhz).Normalized());
                    st.SetUV(new Vector2(x / (float)(res - 1), z / (float)(res - 1)));
                    st.AddVertex(new Vector3(-w.size * 0.5f + x * cell, h[i] * hs, -w.size * 0.5f + z * cell));
                }
            for (int z = 0; z < res - 1; z++)
                for (int x = 0; x < res - 1; x++)
                {
                    int i = z * res + x;   // clockwise seen from above (Godot front face)
                    st.AddIndex(i); st.AddIndex(i + 1); st.AddIndex(i + res);
                    st.AddIndex(i + 1); st.AddIndex(i + res + 1); st.AddIndex(i + res);
                }
            st.GenerateTangents();
            var mesh = st.Commit();

            if (terrainSh == null) { terrainSh = new Shader(); terrainSh.Code = TerrainShader; }
            var tm = new ShaderMaterial(); tm.Shader = terrainSh;
            var grass = RenderBoost.Get(RenderBoost.Kind.Grass);
            tm.SetShaderParameter("base_tex", BuildColorTexture(info, w, GetPal(w.biome)));
            tm.SetShaderParameter("detail_albedo", grass.albedo); tm.SetShaderParameter("detail_normal", grass.normal);
            tm.SetShaderParameter("tile", Mathf.Max(8f, w.size / 3f));
            terrainMI = new MeshInstance3D { Name = "Terrain", Mesh = mesh, MaterialOverride = tm };
            parent.AddChild(terrainMI);

            // ---- water ----
            if (waterSh == null) { waterSh = new Shader(); waterSh.Code = WaterShader; }
            var wm = new ShaderMaterial(); wm.Shader = waterSh; wm.SetShaderParameter("nrm", RenderBoost.Get(RenderBoost.Kind.Water).normal);
            waterMI = new MeshInstance3D { Name = "Water", Mesh = new PlaneMesh { Size = new Vector2(w.size * 1.6f, w.size * 1.6f) }, MaterialOverride = wm };
            waterMI.CastShadow = GeometryInstance3D.ShadowCastingSetting.Off;
            parent.AddChild(waterMI); waterMI.Position = new Vector3(0, w.waterLevel, 0);
            return info;
        }

        static ImageTexture BuildColorTexture(TerrainInfo info, WorldData w, Pal p)
        {
            const int T = 512;
            var px = new byte[T * T * 4];
            for (int j = 0; j < T; j++)
                for (int i = 0; i < T; i++)
                {
                    float wx = (i / (float)(T - 1) - 0.5f) * info.Size, wz = (j / (float)(T - 1) - 0.5f) * info.Size;
                    float hh = info.HeightAt(wx, wz), slope = info.Slope(wx, wz), h01 = hh / info.HeightScale;
                    float n1 = PerlinN.Perlin01(wx * 0.15f + w.seed, wz * 0.15f), n2 = PerlinN.Perlin01(wx * 1.3f, wz * 1.3f + w.seed);
                    float v = (n1 - 0.5f) * 0.22f + (n2 - 0.5f) * 0.12f;
                    Color c;
                    if (hh < w.waterLevel + 0.9f) c = U.LerpC(p.sand, p.low, U.InvLerp(w.waterLevel + 0.2f, w.waterLevel + 0.9f, hh));
                    else if (h01 < 0.45f) c = U.LerpC(p.low, p.mid, U.InvLerp(0.1f, 0.45f, h01));
                    else c = U.LerpC(p.mid, p.high, U.InvLerp(0.45f, 0.85f, h01));
                    c = U.LerpC(c, p.rock, U.Smooth(U.InvLerp(0.45f, 0.95f, slope)));
                    int o = (j * T + i) * 4;
                    px[o] = (byte)Mathf.RoundToInt(U.Clamp01(c.R + v) * 255f); px[o + 1] = (byte)Mathf.RoundToInt(U.Clamp01(c.G + v) * 255f);
                    px[o + 2] = (byte)Mathf.RoundToInt(U.Clamp01(c.B + v) * 255f); px[o + 3] = 255;
                }
            var img = Image.CreateFromData(T, T, false, Image.Format.Rgba8, px);
            img.GenerateMipmaps();
            return ImageTexture.CreateFromImage(img);
        }
    }
}
