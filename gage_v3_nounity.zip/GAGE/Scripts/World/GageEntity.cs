using System.Collections.Generic;
using Godot;

namespace GAGE
{
    /// <summary>Root node of every object in the world (tree, enemy, coin ...). Holds its EntityData.</summary>
    public partial class GageEntity : Node3D
    {
        public EntityData data;

        public static void CollectMeshes(Node n, List<MeshInstance3D> list)
        {
            var mi = n as MeshInstance3D; if (mi != null && mi.Mesh != null && mi.Visible) list.Add(mi);
            foreach (Node c in n.GetChildren()) CollectMeshes(c, list);
        }

        /// <summary>World-space bounding box of all meshes (used for picking + selection marker).</summary>
        public bool WorldBounds(out Aabb box)
        {
            var list = new List<MeshInstance3D>(); CollectMeshes(this, list); box = new Aabb();
            if (list.Count == 0) return false;
            bool first = true;
            foreach (var mi in list)
            {
                Aabb b = mi.GlobalTransform * mi.GetAabb();
                if (first) { box = b; first = false; } else box = box.Merge(b);
            }
            return true;
        }
    }
}
