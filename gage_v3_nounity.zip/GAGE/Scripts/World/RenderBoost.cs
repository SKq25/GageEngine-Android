using Godot;

namespace GAGE
{
    /// <summary>
    /// Realism pass that needs no downloaded assets: high-quality shadows / MSAA / anisotropic filtering plus procedurally generated,
    /// tileable detail albedo + normal maps (grass, rock, bark, plaster, water) layered on the base colours.
    /// Real photoreal models still come from res://Prefabs/*.tscn or Sketchfab (see README).
    /// </summary>
    public static class RenderBoost
    {
        public enum Kind { Grass = 0, Rock = 1, Bark = 2, Plaster = 3, Water = 4 }
        const int N = 256;
        public class Pair { public ImageTexture albedo, normal; }
        static readonly Pair[] cache = new Pair[5];

        public static bool Mobile { get { return OS.HasFeature("mobile"); } }

        public static void ApplyQuality(Viewport vp)
        {
            if (vp == null) return;
            vp.Msaa3D = Mobile ? Viewport.Msaa.Msaa2X : Viewport.Msaa.Msaa4X;
            vp.ScreenSpaceAA = Viewport.ScreenSpaceAAEnum.Disabled;
        }

        // ---------- detail on props ----------
        public static void DetailProp(Node3D root, string type)
        {
            Kind k; float tile;
            switch (type)
            {
                case "tree": case "pine": k = Kind.Bark; tile = 2f; break;
                case "rock": k = Kind.Rock; tile = 3f; break;
                case "house": case "tower": case "crate": k = Kind.Plaster; tile = 3f; break;
                default: return;
            }
            var p = Get(k);
            ApplyRec(root, p, tile, 0.9f);
        }

        static void ApplyRec(Node n, Pair p, float tile, float ns)
        {
            var mi = n as MeshInstance3D;
            if (mi != null)
            {
                var m = mi.MaterialOverride as StandardMaterial3D;
                if (m != null && !m.EmissionEnabled && m.Transparency == BaseMaterial3D.TransparencyEnum.Disabled)
                {
                    m.AlbedoTexture = p.albedo; m.NormalEnabled = true; m.NormalTexture = p.normal; m.NormalScale = ns;
                    m.Uv1Scale = new Vector3(tile, tile, tile);
                    m.TextureFilter = BaseMaterial3D.TextureFilterEnum.LinearWithMipmapsAnisotropic;
                }
            }
            foreach (Node c in n.GetChildren()) ApplyRec(c, p, tile, ns);
        }

        public static Pair Get(Kind k)
        {
            int i = (int)k; if (cache[i] != null) return cache[i];
            var h = new float[N * N];
            for (int y = 0; y < N; y++)
                for (int x = 0; x < N; x++) h[y * N + x] = Height(k, x / (float)N, y / (float)N);

            var ca = new byte[N * N * 4]; var cn = new byte[N * N * 4]; float str = k == Kind.Rock ? 5f : (k == Kind.Water ? 6f : 3f);
            for (int y = 0; y < N; y++)
                for (int x = 0; x < N; x++)
                {
                    int o = (y * N + x) * 4; float v = h[y * N + x];
                    // albedo detail: mean ~1.0 so it multiplies the base colour without darkening it
                    byte g = (byte)Mathf.Clamp(Mathf.RoundToInt((0.88f + (v - 0.5f) * 0.55f) * 255f), 0, 255);
                    ca[o] = g; ca[o + 1] = g; ca[o + 2] = g; ca[o + 3] = 255;
                    float dx = h[y * N + (x + 1) % N] - h[y * N + (x + N - 1) % N], dy = h[((y + 1) % N) * N + x] - h[((y + N - 1) % N) * N + x];
                    var n = new Vector3(-dx * str, -dy * str, 1f).Normalized();
                    cn[o] = (byte)Mathf.RoundToInt((n.X * 0.5f + 0.5f) * 255f); cn[o + 1] = (byte)Mathf.RoundToInt((n.Y * 0.5f + 0.5f) * 255f);
                    cn[o + 2] = (byte)Mathf.RoundToInt((n.Z * 0.5f + 0.5f) * 255f); cn[o + 3] = 255;
                }
            cache[i] = new Pair { albedo = MakeTex(ca), normal = MakeTex(cn) }; return cache[i];
        }

        static ImageTexture MakeTex(byte[] rgba)
        {
            var img = Image.CreateFromData(N, N, false, Image.Format.Rgba8, rgba);
            img.GenerateMipmaps();
            return ImageTexture.CreateFromImage(img);
        }

        static float Height(Kind k, float u, float v)
        {
            switch (k)
            {
                case Kind.Rock: { float a = Fbm(u, v, 4, 5, -1), r = 1f - Mathf.Abs(a * 2f - 1f); return U.Clamp01(r * 0.75f + Fbm(u, v, 16, 3, -1) * 0.25f); }
                case Kind.Bark: return U.Clamp01(Fbm(u, v, 3, 4, 14) * 0.8f + Fbm(u, v, 24, 2, 40) * 0.2f);
                case Kind.Plaster: return U.Clamp01(Fbm(u, v, 8, 4, -1) * 0.6f + Fbm(u, v, 32, 2, -1) * 0.4f);
                case Kind.Water: return U.Clamp01(Fbm(u, v, 5, 5, -1));
                default: return U.Clamp01(Fbm(u, v, 6, 4, -1) * 0.5f + Fbm(u, v, 28, 3, -1) * 0.5f);
            }
        }

        /// <summary>Tileable fractal value noise. fx/fy = lattice cells across the tile (stretched when different).</summary>
        static float Fbm(float u, float v, int fx, int octaves, int fy)
        {
            if (fy < 0) fy = fx; float sum = 0, amp = 1, tot = 0;
            for (int o = 0; o < octaves; o++) { sum += amp * Value(u, v, fx << o, fy << o, o * 131); tot += amp; amp *= 0.5f; }
            return sum / tot;
        }

        static float Value(float u, float v, int cx, int cy, int seed)
        {
            float x = u * cx, y = v * cy; int x0 = Mathf.FloorToInt(x), y0 = Mathf.FloorToInt(y); float tx = x - x0, ty = y - y0;
            tx = tx * tx * (3f - 2f * tx); ty = ty * ty * (3f - 2f * ty);
            float a = Hash(x0 % cx, y0 % cy, seed), b = Hash((x0 + 1) % cx, y0 % cy, seed), c = Hash(x0 % cx, (y0 + 1) % cy, seed), d = Hash((x0 + 1) % cx, (y0 + 1) % cy, seed);
            return U.Lerp(U.Lerp(a, b, tx), U.Lerp(c, d, tx), ty);
        }

        static float Hash(int x, int y, int seed)
        {
            unchecked { uint h = (uint)(x * 374761393 + y * 668265263 + seed * 2147483647); h = (h ^ (h >> 13)) * 1274126177u; h ^= h >> 16; return (h & 0xFFFFFF) / (float)0xFFFFFF; }
        }
    }
}
