using System.Collections.Generic;
using Godot;

namespace GAGE
{
    /// <summary>
    /// Builds every object type procedurally. Drop your own realistic scene in res://Prefabs/&lt;type&gt;.tscn
    /// (e.g. tree.tscn, house.tscn, enemy.tscn) and GAGE uses it instead of the built-in shape (this is how you get photoreal assets).
    /// Models face -Z (Godot convention).
    /// </summary>
    public static class PropFactory
    {
        public enum Shape { Cube, Sphere, Cylinder, Capsule }
        static readonly Dictionary<int, Mesh> rocks = new Dictionary<int, Mesh>();
        static readonly Dictionary<Shape, Mesh> prims = new Dictionary<Shape, Mesh>();

        static Mesh Prim(Shape s)
        {
            Mesh m;
            if (prims.TryGetValue(s, out m)) return m;
            switch (s)
            {
                case Shape.Cube: m = new BoxMesh { Size = Vector3.One }; break;
                case Shape.Sphere: m = new SphereMesh { Radius = 0.5f, Height = 1f, RadialSegments = 32, Rings = 16 }; break;
                case Shape.Cylinder: m = new CylinderMesh { TopRadius = 0.5f, BottomRadius = 0.5f, Height = 2f, RadialSegments = 24 }; break;
                default: m = new CapsuleMesh { Radius = 0.5f, Height = 2f, RadialSegments = 24, Rings = 8 }; break;
            }
            prims[s] = m; return m;
        }

        public static GageEntity Create(EntityData e, bool behaviours)
        {
            var root = new GageEntity { Name = e.type, data = e };
            string prefabPath = "res://Prefabs/" + e.type + ".tscn";
            bool custom = false;
            if (ResourceLoader.Exists(prefabPath))
            {
                var ps = GD.Load<PackedScene>(prefabPath);
                var inst = ps != null ? ps.Instantiate() as Node3D : null;
                if (inst != null) { root.AddChild(inst); custom = true; }
            }
            if (!custom)
            {
                var rnd = new System.Random(Mathf.RoundToInt(e.x * 31.7f + e.z * 17.3f) + e.type.Length);
                switch (e.type)
                {
                    case "tree": MakeTree(root, e, rnd, false); break;
                    case "pine": MakeTree(root, e, rnd, true); break;
                    case "rock": MakeRock(root, e, rnd); break;
                    case "house": MakeHouse(root, e); break;
                    case "tower": MakeTower(root, e); break;
                    case "crate": Part(root, Shape.Cube, new Vector3(0, .6f, 0), new Vector3(1.2f, 1.2f, 1.2f), MaterialFactory.Make(U.Parse(e.color, U.C(.5f, .34f, .18f)), .2f), new Vector3(0, 20, 0)); break;
                    case "lamp": MakeLamp(root); break;
                    case "enemy": MakeCreature(root, U.Parse(e.color, U.C(.8f, .15f, .2f)), true); break;
                    case "npc": MakeCreature(root, U.Parse(e.color, U.C(.2f, .4f, .85f)), false); break;
                    case "coin": MakeCoin(root); break;
                    case "spawn": MakeSpawn(root); break;
                    case "model": Part(root, Shape.Cube, new Vector3(0, .75f, 0), Vector3.One * 1.5f, MaterialFactory.Make(U.C(.6f, .6f, .65f), .2f), Vector3.Zero); break;
                    default: Part(root, Shape.Cube, new Vector3(0, .5f, 0), Vector3.One, MaterialFactory.Make(new Color(1f, 0f, 1f)), Vector3.Zero); break;
                }
                RenderBoost.DetailProp(root, e.type);
            }
            if (e.type == "model") root.AddChild(new ModelLoader { Name = "ModelLoader", uid = e.text });
            if (behaviours)
            {
                if (e.type == "enemy") root.AddChild(new EnemyAI3D { Name = "EnemyAI", speed = Mathf.Clamp(e.speed, 0.5f, 8f), behavior = e.behavior });
                else if (e.type == "coin") root.AddChild(new Collectible3D { Name = "Collectible", points = Mathf.Max(1, e.points) });
                else if (e.type == "npc") root.AddChild(new AINpc { Name = "AINpc", persona = string.IsNullOrEmpty(e.text) ? "A friendly villager." : e.text });
            }
            return root;
        }

        public static Node3D CreatePlayer()
        {
            var root = new Node3D { Name = "Player" };
            Part(root, Shape.Capsule, new Vector3(0, .9f, 0), new Vector3(.8f, .9f, .8f), MaterialFactory.Make(U.C(.15f, .6f, .35f), .35f), Vector3.Zero);
            Part(root, Shape.Sphere, new Vector3(0, 1.85f, 0), Vector3.One * .5f, MaterialFactory.Make(U.C(.95f, .78f, .62f), .3f), Vector3.Zero);
            Part(root, Shape.Cube, new Vector3(0, 1.85f, -.27f), new Vector3(.12f, .12f, .12f), MaterialFactory.Make(Colors.Black), Vector3.Zero);
            return root;
        }

        // ---------- helpers ----------
        public static MeshInstance3D Part(Node3D parent, Shape s, Vector3 pos, Vector3 scale, Material m, Vector3 eulerDeg)
        {
            var g = new MeshInstance3D { Mesh = Prim(s), MaterialOverride = m };
            parent.AddChild(g); g.Position = pos; g.Scale = scale; g.RotationDegrees = eulerDeg; return g;
        }

        static void MakeTree(Node3D p, EntityData e, System.Random r, bool pine)
        {
            float v = (float)r.NextDouble();
            var bark = MaterialFactory.Make(U.C(.32f, .21f, .12f), .1f);
            Color leaf = U.Parse(e.color, pine ? U.C(.08f + v * .05f, .28f + v * .1f, .14f) : U.C(.14f + v * .12f, .4f + v * .15f, .1f + v * .05f));
            var lm = MaterialFactory.Make(leaf, .15f);
            Part(p, Shape.Cylinder, new Vector3(0, 1.1f, 0), new Vector3(.38f, 1.1f, .38f), bark, Vector3.Zero);
            if (pine)
                for (int i = 0; i < 4; i++)
                    Part(p, Shape.Sphere, new Vector3(0, 2.1f + i * 1.05f, 0), new Vector3(2.8f - i * .6f, 1.5f, 2.8f - i * .6f), lm, Vector3.Zero);
            else
            {
                Part(p, Shape.Sphere, new Vector3(0, 3.3f, 0), new Vector3(3.0f, 2.6f, 3.0f), lm, Vector3.Zero);
                Part(p, Shape.Sphere, new Vector3(.7f, 4.2f, .3f), new Vector3(2.0f, 1.8f, 2.0f), lm, Vector3.Zero);
                Part(p, Shape.Sphere, new Vector3(-.6f, 4.0f, -.4f), new Vector3(1.8f, 1.6f, 1.8f), lm, Vector3.Zero);
            }
        }

        // ---- rock: displaced sphere, normals + tangents by SurfaceTool ----
        static void MakeRock(Node3D p, EntityData e, System.Random r)
        {
            int seed = r.Next(0, 4); Mesh m;
            if (!rocks.TryGetValue(seed, out m)) { m = BuildRock(seed); rocks[seed] = m; }
            var col = U.Parse(e.color, U.C(.42f + (float)r.NextDouble() * .1f, .4f, .38f));
            var g = new MeshInstance3D { Mesh = m, MaterialOverride = MaterialFactory.Make(col, .2f) };
            p.AddChild(g); g.Scale = new Vector3(1.6f, 1.1f, 1.4f); g.Position = new Vector3(0, .45f, 0);
            g.RotationDegrees = new Vector3(0, (float)r.NextDouble() * 360f, 0);
        }

        static Mesh BuildRock(int seed)
        {
            const int seg = 24, rings = 14;
            var pos = new Vector3[(rings + 1) * (seg + 1)]; var uv = new Vector2[pos.Length]; var nor = new Vector3[pos.Length];
            for (int i = 0; i <= rings; i++)
                for (int j = 0; j <= seg; j++)
                {
                    float th = Mathf.Pi * i / rings, ph = Mathf.Tau * j / seg;
                    var d = new Vector3(Mathf.Sin(th) * Mathf.Cos(ph), Mathf.Cos(th), Mathf.Sin(th) * Mathf.Sin(ph));
                    // seamless: sample the noise from the 3D direction
                    float n = PerlinN.Perlin01(d.X * 2.4f + seed * 7.3f + 5f, d.Y * 2.2f + d.Z * 1.9f + seed * 3.1f + 5f);
                    int k = i * (seg + 1) + j; pos[k] = d * 0.5f * (0.7f + n * 0.7f); nor[k] = d; uv[k] = new Vector2(j / (float)seg, i / (float)rings);
                }
            var st = new SurfaceTool(); st.Begin(Mesh.PrimitiveType.Triangles);
            for (int k = 0; k < pos.Length; k++) { st.SetNormal(nor[k]); st.SetUV(uv[k]); st.AddVertex(pos[k]); }
            for (int i = 0; i < rings; i++)
                for (int j = 0; j < seg; j++)
                {
                    int a = i * (seg + 1) + j, b = a + 1, c = a + seg + 1, d2 = c + 1;
                    TriIdx(st, pos, a, c, b); TriIdx(st, pos, b, c, d2);
                }
            st.GenerateTangents();
            return st.Commit();
        }

        /// <summary>Adds a triangle whose winding is clockwise seen from outside (Godot front face), whatever order was given.</summary>
        static void TriIdx(SurfaceTool st, Vector3[] pos, int a, int b, int c)
        {
            Vector3 outward = (pos[a] + pos[b] + pos[c]);   // sphere-like shape centred on the origin
            Vector3 n = (pos[b] - pos[a]).Cross(pos[c] - pos[a]);
            if (n.Dot(outward) > 0f) { int t = b; b = c; c = t; }   // counter-clockwise from outside -> flip
            st.AddIndex(a); st.AddIndex(b); st.AddIndex(c);
        }

        static void MakeHouse(Node3D p, EntityData e)
        {
            var wall = MaterialFactory.Make(U.Parse(e.color, U.C(.82f, .74f, .6f)), .1f);
            Part(p, Shape.Cube, new Vector3(0, 1.3f, 0), new Vector3(4f, 2.6f, 5f), wall, Vector3.Zero);
            var roofMat = MaterialFactory.Make(U.C(.55f, .2f, .15f), .15f); roofMat.CullMode = BaseMaterial3D.CullModeEnum.Disabled;
            var roof = new MeshInstance3D { Mesh = BuildRoof(4.8f, 5.8f, 1.7f), MaterialOverride = roofMat };
            p.AddChild(roof); roof.Position = new Vector3(0, 2.6f, 0);
            Part(p, Shape.Cube, new Vector3(0, .9f, 2.51f), new Vector3(.9f, 1.8f, .1f), MaterialFactory.Make(U.C(.3f, .18f, .1f), .2f), Vector3.Zero);   // door on the -Z... front is +Z here, camera-agnostic
            var win = MaterialFactory.Make(U.C(.5f, .7f, .85f), .9f, .1f);
            Part(p, Shape.Cube, new Vector3(1.9f, 1.5f, .8f), new Vector3(.1f, .8f, .9f), win, Vector3.Zero);
            Part(p, Shape.Cube, new Vector3(-1.9f, 1.5f, .8f), new Vector3(.1f, .8f, .9f), win, Vector3.Zero);
        }

        static Mesh BuildRoof(float w, float l, float h)
        {
            Vector3 A = new Vector3(-w / 2, 0, -l / 2), B = new Vector3(w / 2, 0, -l / 2), C = new Vector3(w / 2, 0, l / 2), D = new Vector3(-w / 2, 0, l / 2);
            Vector3 R1 = new Vector3(0, h, -l / 2), R2 = new Vector3(0, h, l / 2);
            var st = new SurfaceTool(); st.Begin(Mesh.PrimitiveType.Triangles);
            RoofQuad(st, A, R1, R2, D, new Vector3(-1, 1, 0)); RoofQuad(st, B, C, R2, R1, new Vector3(1, 1, 0));
            RoofTri(st, A, B, R1, new Vector3(0, 0, -1)); RoofTri(st, D, C, R2, new Vector3(0, 0, 1));
            RoofQuad(st, A, B, C, D, new Vector3(0, -1, 0));
            return st.Commit();
        }
        static void RoofTri(SurfaceTool st, Vector3 a, Vector3 b, Vector3 c, Vector3 outward)
        {
            Vector3 n = (b - a).Cross(c - a);
            if (n.Dot(outward) > 0f) { var t = b; b = c; c = t; n = -n; }   // want clockwise from outside
            Vector3 fn = (-n).Normalized();                                  // outward face normal
            st.SetNormal(fn); st.AddVertex(a); st.SetNormal(fn); st.AddVertex(b); st.SetNormal(fn); st.AddVertex(c);
        }
        static void RoofQuad(SurfaceTool st, Vector3 a, Vector3 b, Vector3 c, Vector3 d, Vector3 outward) { RoofTri(st, a, b, c, outward); RoofTri(st, a, c, d, outward); }

        static void MakeTower(Node3D p, EntityData e)
        {
            Part(p, Shape.Cylinder, new Vector3(0, 4f, 0), new Vector3(2.4f, 4f, 2.4f), MaterialFactory.Make(U.Parse(e.color, U.C(.6f, .58f, .55f)), .15f), Vector3.Zero);
            Part(p, Shape.Sphere, new Vector3(0, 8.4f, 0), new Vector3(3.2f, 2.4f, 3.2f), MaterialFactory.Make(U.C(.6f, .15f, .12f), .2f), Vector3.Zero);
        }

        static void MakeLamp(Node3D p)
        {
            Part(p, Shape.Cylinder, new Vector3(0, 1.6f, 0), new Vector3(.14f, 1.6f, .14f), MaterialFactory.Make(U.C(.15f, .15f, .17f), .5f, .6f), Vector3.Zero);
            Part(p, Shape.Sphere, new Vector3(0, 3.4f, 0), Vector3.One * .45f, MaterialFactory.Make(U.C(1f, .9f, .6f), .5f, 0f, false, new Color(1.6f, 1.3f, .7f)), Vector3.Zero);
            var li = new OmniLight3D { OmniRange = 14f, LightEnergy = 1.6f, LightColor = U.C(1f, .85f, .55f), ShadowEnabled = false };
            p.AddChild(li); li.Position = new Vector3(0, 3.4f, 0);
        }

        static void MakeCreature(Node3D p, Color c, bool evil)
        {
            var body = MaterialFactory.Make(c, .4f);
            Part(p, Shape.Capsule, new Vector3(0, 1f, 0), new Vector3(1f, 1f, 1f), body, Vector3.Zero);
            Part(p, Shape.Sphere, new Vector3(0, 2.15f, 0), Vector3.One * .75f, evil ? body : MaterialFactory.Make(U.C(.95f, .78f, .62f), .3f), Vector3.Zero);
            var white = MaterialFactory.Make(Colors.White, .6f); var black = MaterialFactory.Make(Colors.Black, .8f);
            foreach (float s in new[] { -1f, 1f })
            {
                Part(p, Shape.Sphere, new Vector3(.17f * s, 2.25f, -.3f), Vector3.One * .2f, white, Vector3.Zero);
                Part(p, Shape.Sphere, new Vector3(.17f * s, 2.25f, -.4f), Vector3.One * .09f, black, Vector3.Zero);
                if (evil) Part(p, Shape.Cube, new Vector3(.28f * s, 2.62f, 0f), new Vector3(.12f, .4f, .12f), MaterialFactory.Make(U.C(.9f, .85f, .7f)), new Vector3(0, 0, -20f * s));
            }
        }

        static void MakeCoin(Node3D p)
        {
            Part(p, Shape.Cylinder, Vector3.Zero, new Vector3(.8f, .06f, .8f), MaterialFactory.Make(U.C(1f, .82f, .2f), .85f, .9f, false, new Color(.5f, .38f, 0f)), new Vector3(90, 0, 0));
        }

        static void MakeSpawn(Node3D p)
        {
            Part(p, Shape.Cylinder, new Vector3(0, 1.2f, 0), new Vector3(.08f, 1.2f, .08f), MaterialFactory.Make(Colors.White), Vector3.Zero);
            Part(p, Shape.Cube, new Vector3(.45f, 2.1f, 0), new Vector3(.9f, .5f, .04f), MaterialFactory.Make(U.C(.2f, .8f, .3f), .3f, 0f, false, new Color(0f, .4f, .1f)), Vector3.Zero);
        }
    }
}
