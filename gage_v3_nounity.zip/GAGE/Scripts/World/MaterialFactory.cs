using Godot;

namespace GAGE
{
    public static class MaterialFactory
    {
        /// <summary>Standard PBR material. smooth = 0..1 (roughness = 1 - smooth).</summary>
        public static StandardMaterial3D Make(Color c, float smooth = 0.3f, float metal = 0f, bool transparent = false, Color? emission = null)
        {
            var m = new StandardMaterial3D();
            m.AlbedoColor = c; m.Roughness = 1f - smooth; m.Metallic = metal;
            m.TextureFilter = BaseMaterial3D.TextureFilterEnum.LinearWithMipmapsAnisotropic;
            if (transparent)
            {
                m.Transparency = BaseMaterial3D.TransparencyEnum.Alpha; m.CullMode = BaseMaterial3D.CullModeEnum.Disabled;
            }
            if (emission.HasValue)
            {
                m.EmissionEnabled = true; m.Emission = new Color(emission.Value.R, emission.Value.G, emission.Value.B, 1f);
                m.EmissionEnergyMultiplier = Mathf.Max(1f, Mathf.Max(emission.Value.R, Mathf.Max(emission.Value.G, emission.Value.B)));
            }
            return m;
        }
    }
}
