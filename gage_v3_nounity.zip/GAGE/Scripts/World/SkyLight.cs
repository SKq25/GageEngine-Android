using Godot;

namespace GAGE
{
    /// <summary>Time-of-day sun, ambient light, fog, sky and post effects (tonemap, glow, SSAO) for a realistic look.</summary>
    public static class SkyLight
    {
        public static void Apply(WorldData w, DirectionalLight3D sun, Godot.Environment env, ProceduralSkyMaterial sky)
        {
            float t = U.Repeat(w.timeOfDay, 24f);
            float ang = (t - 6f) / 12f * 180f;                       // 0 at 06:00, 90 at noon, 180 at 18:00
            float elev = Mathf.Sin(Mathf.DegToRad(ang));
            float day = U.Clamp01(elev * 2.5f + 0.05f);

            sun.ShadowEnabled = true; sun.ShadowBlur = 1.2f; sun.DirectionalShadowMode = RenderBoost.Mobile ? DirectionalLight3D.ShadowMode.Parallel2Splits : DirectionalLight3D.ShadowMode.Parallel4Splits;
            sun.DirectionalShadowMaxDistance = RenderBoost.Mobile ? 55f : 90f; sun.ShadowNormalBias = 1.2f;
            if (elev > 0f)
            {
                float e = ang <= 90f ? ang : 180f - ang;            // sun height above the horizon in degrees
                sun.RotationDegrees = new Vector3(-Mathf.Max(e, 8f), 35f, 0f);
                sun.LightColor = U.LerpC(U.C(1f, .55f, .25f), U.C(1f, .96f, .88f), U.Clamp01(elev * 2f));
                sun.LightEnergy = 0.2f + 1.1f * day; sun.SkyMode = DirectionalLight3D.SkyModeEnum.LightAndSky;
            }
            else
            {
                sun.RotationDegrees = new Vector3(-55f, -120f, 0f); sun.LightColor = U.C(.45f, .55f, .9f); sun.LightEnergy = 0.28f;
                sun.SkyMode = DirectionalLight3D.SkyModeEnum.LightOnly;   // no sun disc at night
            }

            Color skyDay = U.C(.38f, .6f, .95f), skyNight = U.C(.02f, .03f, .08f), dusk = U.C(.95f, .5f, .3f);
            Color skyTop = U.LerpC(skyNight, skyDay, day);
            float duskAmt = U.Clamp01(1f - Mathf.Abs(elev) * 4f);
            Color horizon = U.LerpC(U.LerpC(U.C(.04f, .05f, .1f), U.C(.75f, .85f, .95f), day), dusk, duskAmt * 0.7f);

            sky.SkyTopColor = skyTop; sky.SkyHorizonColor = horizon; sky.SkyCurve = 0.18f;
            sky.GroundHorizonColor = horizon; sky.GroundBottomColor = U.Mul(U.C(.18f, .16f, .13f), U.Lerp(0.25f, 1f, day)); sky.GroundCurve = 0.05f;
            sky.SunAngleMax = 30f; sky.SunCurve = 0.15f;

            env.BackgroundMode = Godot.Environment.BGMode.Sky;
            env.AmbientLightSource = Godot.Environment.AmbientSource.Sky; env.AmbientLightEnergy = U.Lerp(0.55f, 1f, day);
            env.ReflectedLightSource = Godot.Environment.ReflectionSource.Sky;
            env.TonemapMode = Godot.Environment.ToneMapper.Aces; env.TonemapExposure = U.Lerp(1.25f, 1f, day); env.TonemapWhite = 6f;
            env.FogEnabled = true; env.FogLightColor = horizon; env.FogDensity = Mathf.Clamp(w.fog, 0f, 0.05f) * 0.5f; env.FogSkyAffect = 0.35f;
            env.GlowEnabled = true; env.GlowIntensity = 0.6f; env.GlowBloom = 0.05f;
            env.SsaoEnabled = !RenderBoost.Mobile; env.SsaoRadius = 1.6f; env.SsaoIntensity = 2.2f;   // needs Forward+ (desktop)
            env.AdjustmentEnabled = true; env.AdjustmentContrast = 1.06f; env.AdjustmentSaturation = 1.08f;
        }
    }
}
