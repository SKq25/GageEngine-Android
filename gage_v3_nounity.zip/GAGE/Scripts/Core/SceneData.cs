using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Text.Json.Serialization;
using Godot;

namespace GAGE
{
    /// <summary>Accepts 3 or 3.0 or "3" for int fields (AI models are sloppy with numbers).</summary>
    public class LenientInt : JsonConverter<int>
    {
        public override int Read(ref Utf8JsonReader r, Type t, JsonSerializerOptions o)
        {
            if (r.TokenType == JsonTokenType.Number) return (int)Math.Round(r.GetDouble());
            if (r.TokenType == JsonTokenType.String)
            {
                double d;
                if (double.TryParse(r.GetString(), System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out d)) return (int)Math.Round(d);
                return 0;
            }
            if (r.TokenType == JsonTokenType.StartObject || r.TokenType == JsonTokenType.StartArray) r.Skip();
            return 0;
        }
        public override void Write(Utf8JsonWriter w, int v, JsonSerializerOptions o) { w.WriteNumberValue(v); }
    }

    /// <summary>JSON helper (System.Text.Json, public fields included). Replaces Unity's JsonUtility.</summary>
    public static class GJson
    {
        static readonly JsonSerializerOptions Opts = Make(false), OptsPretty = Make(true);
        static JsonSerializerOptions Make(bool indent)
        {
            var o = new JsonSerializerOptions
            {
                IncludeFields = true, PropertyNameCaseInsensitive = true, ReadCommentHandling = JsonCommentHandling.Skip,
                AllowTrailingCommas = true, NumberHandling = JsonNumberHandling.AllowReadingFromString, WriteIndented = indent
            };
            o.Converters.Add(new LenientInt());
            return o;
        }
        public static string To(object v, bool indent = false) { return JsonSerializer.Serialize(v, v.GetType(), indent ? OptsPretty : Opts); }
        public static T From<T>(string json) { return JsonSerializer.Deserialize<T>(json, Opts); }
    }

    public class WorldData
    {
        public string title = "Untitled"; public string description = "";
        public int seed = 7; public float size = 120f; public float heightScale = 14f; public float roughness = 0.5f;
        public string biome = "grassland"; public float waterLevel = 2.5f; public float timeOfDay = 15f; public float fog = 0.006f;
    }
    public class PlayerData { public float speed = 6f; public int health = 5; }
    public class EntityData
    {
        public string type = "tree"; public float x, y, z, rotY; public float scale = 1f;
        public string color = ""; public string behavior = "chase"; public float speed = 3f; public int points = 1; public string text = "";
    }
    public class SceneData
    {
        public WorldData world = new WorldData(); public PlayerData player = new PlayerData();
        public List<EntityData> entities = new List<EntityData>();
        public int targetScore = 10; public string winText = "You Win!"; public string loseText = "Game Over";
    }

    // ---- AI protocol ----
    public class WorldPatch
    {
        public string title = ""; public string biome = ""; public float timeOfDay = -1; public float fog = -1;
        public float waterLevel = -999; public float heightScale = -1; public float size = -1; public int seed = 0; public int targetScore = -1;
    }
    public class AIOp
    {
        public string op = "add";               // add | remove | world
        public string type = "";                // entity type (remove: type or "all")
        public int count = 1;
        public float cx, cz, radius;            // area (radius 0 = whole map)
        public bool exact;                      // true: place exactly at cx,cz
        public float scale = 1f, scaleVar = 0.3f;
        public string color = "", behavior = "", text = ""; public float speed = 0; public int points = 0;
        public WorldPatch world = new WorldPatch();
    }
    public class AIOps { public string reply = ""; public AIOp[] ops = new AIOp[0]; }
    public class AIGame
    {
        public WorldData world = new WorldData(); public PlayerData player = new PlayerData();
        public int targetScore = 10; public string winText = "You Win!"; public string loseText = "Game Over";
        public AIOp[] ops = new AIOp[0];
    }

    public static class EntityTypes
    {
        public static readonly string[] Palette = { "tree", "pine", "rock", "house", "tower", "crate", "lamp", "enemy", "coin", "npc", "spawn" };
        public static bool IsValid(string t) { return Array.IndexOf(Palette, t) >= 0; }
        public static float DefaultY(string t) { return t == "coin" ? 1.0f : 0f; }
        /// <summary>Navigation obstacle radius (-1 = walkable).</summary>
        public static float ObstacleRadius(string t)
        {
            switch (t)
            {
                case "tree": case "pine": return 0.6f; case "rock": return 1.1f; case "house": return 3.4f;
                case "tower": return 1.5f; case "crate": return 0.8f; case "lamp": return 0.3f; case "model": return 1.5f; default: return -1f;
            }
        }
        public static float MaxSlope(string t) { return (t == "house" || t == "tower") ? 0.25f : 0.9f; }
        public static EntityData Make(string type, float x, float z)
        {
            var e = new EntityData { type = type, x = x, z = z, y = DefaultY(type) };
            if (type == "enemy") { e.speed = 3f; e.behavior = "chase"; }
            if (type == "coin") e.points = 1;
            if (type == "npc") e.text = "A friendly villager who gives short hints.";
            return e;
        }
        public static EntityData Clone(EntityData s) { return GJson.From<EntityData>(GJson.To(s)); }
    }

    public static class SceneStore
    {
        static string FilePath { get { return System.IO.Path.Combine(OS.GetUserDataDir(), "gage_scene.json"); } }
        public static bool Exists { get { return System.IO.File.Exists(FilePath); } }
        public static void Save(SceneData d) { System.IO.File.WriteAllText(FilePath, GJson.To(d, true)); }
        public static SceneData Load() { return GJson.From<SceneData>(System.IO.File.ReadAllText(FilePath)); }

        public static AIGame Demo()
        {
            var g = new AIGame();
            g.world.title = "GAGE Demo Island"; g.world.biome = "grassland"; g.world.seed = 11; g.targetScore = 12;
            Func<string, int, float, AIOp> add = (t, n, r) => new AIOp { op = "add", type = t, count = n, radius = r };
            var spawn = new AIOp { op = "add", type = "spawn", exact = true, cx = 0, cz = 0 };
            var enemyA = add("enemy", 3, 0); enemyA.behavior = "chase"; enemyA.speed = 3.2f;
            var enemyB = add("enemy", 2, 0); enemyB.behavior = "patrol"; enemyB.speed = 2.4f;
            g.ops = new[] { spawn, add("tree", 60, 0), add("pine", 25, 0), add("rock", 22, 0), add("house", 3, 0), add("lamp", 4, 0),
                            add("crate", 6, 0), add("coin", 14, 0), enemyA, enemyB, add("npc", 1, 25) };
            return g;
        }
    }
}
