using System;
using Godot;

namespace GAGE
{
    /// <summary>Small math / colour helpers (replaces the bits of UnityEngine.Mathf / Color that GAGE used).</summary>
    public static class U
    {
        public static readonly Random Rng = new Random();
        public static float Now { get { return Time.GetTicksMsec() / 1000f; } }

        public static float Clamp01(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
        public static float Lerp(float a, float b, float t) { return a + (b - a) * t; }
        public static float InvLerp(float a, float b, float v) { return a == b ? 0f : Clamp01((v - a) / (b - a)); }
        public static float Smooth(float t) { t = Clamp01(t); return t * t * (3f - 2f * t); }
        public static float Repeat(float t, float len) { return t - Mathf.Floor(t / len) * len; }
        public static float Rand(float a, float b) { return a + (float)Rng.NextDouble() * (b - a); }

        public static Color LerpC(Color a, Color b, float t)
        { return new Color(Lerp(a.R, b.R, t), Lerp(a.G, b.G, t), Lerp(a.B, b.B, t), 1f); }
        public static Color Mul(Color c, float k) { return new Color(c.R * k, c.G * k, c.B * k, 1f); }
        public static Color C(float r, float g, float b) { return new Color(r, g, b, 1f); }

        public static Color Parse(string hex, Color fallback)
        {
            if (!string.IsNullOrEmpty(hex) && Color.HtmlIsValid(hex)) return Color.FromHtml(hex);
            return fallback;
        }

        public static Vector2 RandInCircle(float r)
        {
            for (int i = 0; i < 20; i++)
            {
                float x = Rand(-1f, 1f), y = Rand(-1f, 1f);
                if (x * x + y * y <= 1f) return new Vector2(x, y) * r;
            }
            return Vector2.Zero;
        }
    }

    /// <summary>Perlin gradient noise in [0,1] (same role as Unity's Mathf.PerlinNoise).</summary>
    public static class PerlinN
    {
        static float Fade(float t) { return t * t * t * (t * (t * 6f - 15f) + 10f); }
        static uint H(int x, int y)
        {
            unchecked
            {
                uint h = (uint)x * 374761393u + (uint)y * 668265263u;
                h = (h ^ (h >> 13)) * 1274126177u;
                return h ^ (h >> 16);
            }
        }
        static float G(int ix, int iy, float dx, float dy)
        {
            float a = (H(ix, iy) & 0xFFFFu) * (6.2831853f / 65536f);
            return Mathf.Cos(a) * dx + Mathf.Sin(a) * dy;
        }
        public static float Perlin01(float x, float y)
        {
            int x0 = Mathf.FloorToInt(x), y0 = Mathf.FloorToInt(y);
            float fx = x - x0, fy = y - y0, u = Fade(fx), v = Fade(fy);
            float n00 = G(x0, y0, fx, fy), n10 = G(x0 + 1, y0, fx - 1f, fy);
            float n01 = G(x0, y0 + 1, fx, fy - 1f), n11 = G(x0 + 1, y0 + 1, fx - 1f, fy - 1f);
            float a = n00 + u * (n10 - n00), b = n01 + u * (n11 - n01);
            return Clamp((a + v * (b - a)) * 1.4142f * 0.5f + 0.5f);
        }
        static float Clamp(float v) { return v < 0f ? 0f : (v > 1f ? 1f : v); }
    }
}
