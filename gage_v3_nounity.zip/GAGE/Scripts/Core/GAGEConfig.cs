using System;

namespace GAGE
{
    public class ConfigData { public string endpoint = ""; public string accessToken = ""; public string devDirectKey = ""; public string sketchfabToken = ""; public string mpEndpoint = ""; }

    /// <summary>
    /// Reads res://gage_config.json (a copy in user://gage_config.json wins, so you can change it on the phone).
    /// The OpenRouter key is NOT in the app: it lives on the GAGE proxy server (Server/.env). Model is locked to Gemini 2.5 Flash.
    /// </summary>
    public static class GAGEConfig
    {
        public const string Model = "google/gemini-2.5-flash";
        public const string DirectUrl = "https://openrouter.ai/api/v1/chat/completions";
        static ConfigData data;
        static ConfigData D
        {
            get
            {
                if (data == null)
                {
                    try
                    {
                        string user = System.IO.Path.Combine(Godot.OS.GetUserDataDir(), "gage_config.json");
                        string txt = System.IO.File.Exists(user) ? System.IO.File.ReadAllText(user) : Godot.FileAccess.GetFileAsString("res://gage_config.json");
                        data = string.IsNullOrWhiteSpace(txt) ? null : GJson.From<ConfigData>(txt);
                    }
                    catch (Exception e) { Godot.GD.PrintErr("[GAGE] config: " + e.Message); }
                    if (data == null) data = new ConfigData();
                }
                return data;
            }
        }
        public static string Endpoint { get { return (D.endpoint ?? "").Trim(); } }
        public static string AccessToken { get { return D.accessToken ?? ""; } }
        public static string DevKey { get { return D.devDirectKey ?? ""; } }
        /// <summary>Optional explicit multiplayer base URL (e.g. https://gage.onrender.com/mp/). Empty = derived from endpoint.</summary>
        public static string MpEndpoint { get { return (D.mpEndpoint ?? "").Trim(); } }
        public static string SketchfabToken { get { return D.sketchfabToken ?? ""; } }
        public static bool DirectMode { get { return !string.IsNullOrEmpty(DevKey); } }
        public static bool IsConfigured { get { return DirectMode || !string.IsNullOrEmpty(Endpoint); } }
    }
}
