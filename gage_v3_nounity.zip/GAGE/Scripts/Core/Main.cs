using Godot;

namespace GAGE
{
    /// <summary>Entry point (Main.tscn). Creates every GAGE system; nothing else has to be set up in the editor.</summary>
    public partial class Main : Node
    {
        public override void _Ready()
        {
            DisplayServer.ScreenSetKeepOn(true);
            Engine.MaxFps = 60;
            RenderBoost.ApplyQuality(GetViewport());
            AddChild(new GameSession { Name = "GameSession" });
            AddChild(new ScriptHost { Name = "ScriptHost" });
            AddChild(new InputHub { Name = "InputHub" });
            AddChild(new MultiplayerClient { Name = "Multiplayer" });
            AddChild(new SceneBuilder { Name = "SceneBuilder" });
            AddChild(new EditorController { Name = "EditorController" });
            AddChild(new EditorUI { Name = "EditorUI" });   // last: its _Ready loads the first level
        }
    }
}
