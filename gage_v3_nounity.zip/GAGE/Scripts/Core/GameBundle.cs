using System.IO;
using System.IO.Compression;
using System.Text;
using Godot;

namespace GAGE
{
    /// <summary>
    /// Export / Player mode. EXPORT writes a .zip containing gage_game.json (+ a how-to). Put that zip in the GitHub repo root as
    /// game.zip: the workflow unzips it over the project and the build becomes a PLAYER app (no editor UI, starts that game directly).
    /// </summary>
    public static class GameBundle
    {
        public const string ResPath = "res://gage_game.json";
        static bool? exists;
        public static bool Exists { get { if (exists == null) exists = Godot.FileAccess.FileExists(ResPath); return exists.Value; } }

        public static SceneData Load()
        {
            if (!Exists) return null;
            try { return GJson.From<SceneData>(Godot.FileAccess.GetFileAsString(ResPath)); }
            catch (System.Exception e) { GD.PrintErr("[GAGE] bad gage_game.json: " + e.Message); return null; }
        }

        public static string SafeName(string title)
        {
            var sb = new StringBuilder();
            foreach (char c in title ?? "") { if (char.IsLetterOrDigit(c)) sb.Append(c); else if (c == ' ' || c == '_' || c == '-') sb.Append('_'); }
            string s = sb.ToString().Trim('_'); if (s.Length == 0) s = "game"; return s.Length > 30 ? s.Substring(0, 30) : s;
        }

        /// <summary>Writes the zip (Downloads folder if the OS allows it, else the app's user folder). Returns the full path or null.</summary>
        public static string ExportZip(SceneData d, out string fileName, out string json)
        {
            fileName = SafeName(d.world.title) + "_game.zip"; json = GJson.To(d, true);
            string[] dirs = { OS.GetSystemDir(OS.SystemDir.Downloads), OS.GetUserDataDir() };
            foreach (var dir in dirs)
            {
                if (string.IsNullOrEmpty(dir)) continue;
                try
                {
                    string path = Path.Combine(dir, fileName);
                    if (File.Exists(path)) File.Delete(path);
                    using (var fs = new FileStream(path, FileMode.Create))
                    using (var z = new ZipArchive(fs, ZipArchiveMode.Create))
                    {
                        Add(z, "gage_game.json", json);
                        Add(z, "HOW_TO_BUILD.txt", "GAGE game export: " + d.world.title + "\r\n\r\n1. Is zip ko GitHub repo me root par game.zip naam se upload karo (purani game.zip ko replace karo).\r\n2. Actions > Build Android APK > Run workflow.\r\n3. Artifact GAGE-apk = tumhara game (Player mode, editor ke bina).\r\n\r\nNote: online ke liye gage_config.json me endpoint apne https server ka rakho.\r\n");
                    }
                    return path;
                }
                catch (System.Exception e) { GD.PrintErr("[GAGE] export to " + dir + " failed: " + e.Message); }
            }
            return null;
        }

        static void Add(ZipArchive z, string name, string text)
        {
            var e = z.CreateEntry(name);
            using (var w = new StreamWriter(e.Open(), new UTF8Encoding(false))) w.Write(text);
        }
    }
}
