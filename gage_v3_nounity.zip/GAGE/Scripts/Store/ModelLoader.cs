using System.IO;
using Godot;

namespace GAGE
{
    /// <summary>
    /// Loads a downloaded Sketchfab glTF/glb into the world with Godot's built-in runtime glTF importer
    /// (no extra package needed, unlike glTFast in Unity). Child of the "model" entity.
    /// </summary>
    public partial class ModelLoader : Node
    {
        public string uid;
        public const bool Supported = true;
        public static string AssetDir(string id) { return Path.Combine(OS.GetUserDataDir(), "GAGE", "assets", id); }

        public override void _Ready() { CallDeferred(nameof(LoadModel)); }   // after SceneBuilder placed the entity

        void LoadModel()
        {
            var host = GetParent() as Node3D; if (host == null || string.IsNullOrEmpty(uid)) return;
            string dir = AssetDir(uid); if (!Directory.Exists(dir)) return;
            string file = null;
            foreach (var f in Directory.GetFiles(dir, "*.*", SearchOption.AllDirectories))
            { string ext = Path.GetExtension(f).ToLowerInvariant(); if (ext == ".gltf" || ext == ".glb") { file = f; break; } }
            if (file == null) return;
            var doc = new GltfDocument(); var state = new GltfState();
            if (doc.AppendFromFile(file, state) != Error.Ok) { GD.PrintErr("[GAGE] glTF load failed: " + file); return; }
            var scene = doc.GenerateScene(state) as Node3D; if (scene == null) return;

            // hide the placeholder box, then scale the model to ~3 m and put it on the ground
            foreach (Node c in host.GetChildren()) { var mi = c as MeshInstance3D; if (mi != null) mi.Visible = false; }
            host.AddChild(scene);
            var list = new System.Collections.Generic.List<MeshInstance3D>(); GageEntity.CollectMeshes(scene, list);
            if (list.Count == 0) return;
            Aabb b = Bounds(list); float m = Mathf.Max(b.Size.X, Mathf.Max(b.Size.Y, b.Size.Z)); float s = m > 1e-4f ? 3f / m : 1f;
            scene.Scale = Vector3.One * s; b = Bounds(list);
            Vector3 hp = host.GlobalPosition;
            scene.GlobalPosition += new Vector3(hp.X - (b.Position.X + b.Size.X * 0.5f), hp.Y - b.Position.Y, hp.Z - (b.Position.Z + b.Size.Z * 0.5f));
        }

        static Aabb Bounds(System.Collections.Generic.List<MeshInstance3D> l)
        {
            Aabb b = l[0].GlobalTransform * l[0].GetAabb();
            for (int i = 1; i < l.Count; i++) b = b.Merge(l[i].GlobalTransform * l[i].GetAabb());
            return b;
        }
    }
}
