using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace GAGE
{
    /// <summary>Search Sketchfab and download a model (glTF zip). Downloading needs YOUR Sketchfab API token in gage_config.json.</summary>
    public static class SketchfabClient
    {
        public class Result { public string uid, name, author, viewerUrl; public int faces; }
        static readonly HttpClient Http = new HttpClient { Timeout = TimeSpan.FromSeconds(300) };

        public static async Task<List<Result>> Search(string q)
        {
            string url = "https://api.sketchfab.com/v3/search?type=models&downloadable=true&count=6&sort_by=-likeCount&q=" + Uri.EscapeDataString(q);
            string txt;
            try { txt = await Http.GetStringAsync(url); } catch (Exception e) { throw new Exception("Sketchfab error: " + e.Message); }
            var list = new List<Result>();
            try
            {
                using (var doc = JsonDocument.Parse(txt))
                {
                    JsonElement results;
                    if (!doc.RootElement.TryGetProperty("results", out results)) return list;
                    foreach (var m in results.EnumerateArray())
                    {
                        var r = new Result { uid = Str(m, "uid"), name = Str(m, "name"), viewerUrl = Str(m, "viewerUrl") };
                        JsonElement fc; if (m.TryGetProperty("faceCount", out fc) && fc.ValueKind == JsonValueKind.Number) r.faces = fc.GetInt32();
                        JsonElement u; if (m.TryGetProperty("user", out u)) r.author = Str(u, "displayName");
                        list.Add(r);
                    }
                }
            }
            catch (Exception e) { throw new Exception("Sketchfab parse error: " + e.Message); }
            return list;
        }

        static string Str(JsonElement e, string name)
        {
            JsonElement v; if (e.TryGetProperty(name, out v) && v.ValueKind == JsonValueKind.String) return v.GetString(); return "";
        }

        /// <summary>Downloads + unzips to user://GAGE/assets/&lt;uid&gt;. Returns the folder.</summary>
        public static async Task<string> Download(string uid, string token)
        {
            if (string.IsNullOrEmpty(token)) throw new Exception("Sketchfab token nahi hai (gage_config.json -> sketchfabToken).");
            string dir = ModelLoader.AssetDir(uid);
            if (Directory.Exists(dir)) return dir;
            string link = null;
            using (var req = new HttpRequestMessage(HttpMethod.Get, "https://api.sketchfab.com/v3/models/" + uid + "/download"))
            {
                req.Headers.TryAddWithoutValidation("Authorization", "Token " + token);
                using (var resp = await Http.SendAsync(req))
                {
                    if (!resp.IsSuccessStatusCode) throw new Exception("Download link error: HTTP " + (int)resp.StatusCode + " (token/license check karo)");
                    try
                    {
                        using (var doc = JsonDocument.Parse(await resp.Content.ReadAsStringAsync()))
                        {
                            JsonElement g, u;
                            if (doc.RootElement.TryGetProperty("gltf", out g) && g.TryGetProperty("url", out u)) link = u.GetString();
                        }
                    }
                    catch (Exception) { }
                }
            }
            if (link == null) throw new Exception("Is model ka glTF download nahi mila.");
            Directory.CreateDirectory(Path.GetDirectoryName(dir)); string zip = dir + ".zip";
            try
            {
                using (var resp = await Http.GetAsync(link, HttpCompletionOption.ResponseHeadersRead))
                {
                    if (!resp.IsSuccessStatusCode) throw new Exception("Model download fail: HTTP " + (int)resp.StatusCode);
                    using (var fs = new FileStream(zip, FileMode.Create)) await resp.Content.CopyToAsync(fs);
                }
                System.IO.Compression.ZipFile.ExtractToDirectory(zip, dir); File.Delete(zip);
            }
            catch (Exception e) { throw new Exception("Model download/unzip error: " + e.Message); }
            return dir;
        }
    }
}
