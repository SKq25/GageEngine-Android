using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using Godot;

namespace GAGE
{
    /// <summary>C# <-> C++ bridge. If the native library is missing, pure C# fallbacks run so GAGE always works.</summary>
    public static class NativeBridge
    {
        const string Lib = "gage_native";
        [DllImport(Lib)] static extern int gage_version();
        [DllImport(Lib)] static extern void gage_heightmap([Out] float[] outH, int w, int h, float scale, int seed, int octaves, float persistence, float ridged);
        [DllImport(Lib)] static extern int gage_astar(byte[] grid, int w, int h, int sx, int sz, int gx, int gz, [Out] int[] outPath, int maxLen);
        [DllImport(Lib)] static extern void gage_separation(float[] pos, int n, float radius, [Out] float[] outForce);

        static NativeBridge()
        {
            try { NativeLibrary.SetDllImportResolver(typeof(NativeBridge).Assembly, Resolve); } catch (Exception) { }
        }

        // Looks for the library in <project>/Native/bin and next to the game executable (desktop). On Android the .so is picked up
        // from the APK's lib folder by the normal loader (see README, "C++ on Android").
        static IntPtr Resolve(string name, Assembly asm, DllImportSearchPath? path)
        {
            if (name != Lib) return IntPtr.Zero;
            string os = OS.GetName(), file = os == "Windows" ? "gage_native.dll" : (os == "macOS" ? "libgage_native.dylib" : "libgage_native.so");
            var dirs = new List<string>();
            try { dirs.Add(ProjectSettings.GlobalizePath("res://Native/bin")); } catch (Exception) { }
            try { dirs.Add(Path.GetDirectoryName(OS.GetExecutablePath())); } catch (Exception) { }
            foreach (var d in dirs)
            {
                if (string.IsNullOrEmpty(d)) continue;
                string p = Path.Combine(d, file); IntPtr h;
                if (File.Exists(p) && NativeLibrary.TryLoad(p, out h)) return h;
            }
            return IntPtr.Zero;
        }

        static int state; // 0 unknown, 1 native, -1 fallback
        public static bool Available
        {
            get
            {
                if (state == 0) { try { state = gage_version() > 0 ? 1 : -1; } catch (Exception) { state = -1; } }
                return state == 1;
            }
        }
        public static string Status { get { return Available ? "C++ native: ON" : "C++ native: OFF (C# fallback)"; } }

        // ---------------- Heightmap ----------------
        public static float[] Heightmap(int w, int h, float scale, int seed, int octaves, float persistence, float ridged)
        {
            var o = new float[w * h];
            if (Available)
            {
                try { gage_heightmap(o, w, h, scale, seed, octaves, persistence, ridged); return o; }
                catch (Exception) { state = -1; }
            }
            float mn = 1e9f, mx = -1e9f;
            for (int z = 0; z < h; z++)
                for (int x = 0; x < w; x++)
                {
                    float amp = 1, freq = 1, sum = 0, norm = 0;
                    for (int k = 0; k < octaves; k++)
                    {
                        float n = PerlinN.Perlin01(x / (float)w * scale * freq + seed * 17.3f + k * 31f,
                                                   z / (float)h * scale * freq + seed * 9.1f + k * 17f);
                        float r = 1f - Mathf.Abs(n * 2f - 1f);
                        n = n * (1f - ridged) + r * r * ridged;
                        sum += n * amp; norm += amp; amp *= persistence; freq *= 2f;
                    }
                    float v = sum / norm; o[z * w + x] = v;
                    if (v < mn) mn = v;
                    if (v > mx) mx = v;
                }
            float range = Mathf.Max(1e-5f, mx - mn);
            for (int i = 0; i < o.Length; i++) o[i] = (o[i] - mn) / range;
            return o;
        }

        // ---------------- A* ----------------
        /// <summary>grid: 0 = walkable. Returns cell indices (z*w+x) start->goal, or null.</summary>
        public static int[] AStar(byte[] grid, int w, int h, int sx, int sz, int gx, int gz)
        {
            int maxLen = w * h;
            if (Available)
            {
                try
                {
                    var path = new int[maxLen];
                    int n = gage_astar(grid, w, h, sx, sz, gx, gz, path, maxLen);
                    if (n <= 0) return null;
                    var r = new int[n]; Array.Copy(path, r, n); return r;
                }
                catch (Exception) { state = -1; }
            }
            return AStarManaged(grid, w, h, sx, sz, gx, gz);
        }

        struct HN { public float k; public int v; }
        class Heap
        {
            readonly List<HN> a = new List<HN>();
            public int Count { get { return a.Count; } }
            public void Push(float k, int v)
            {
                a.Add(new HN { k = k, v = v }); int i = a.Count - 1;
                while (i > 0) { int p = (i - 1) / 2; if (a[p].k <= a[i].k) break; var t = a[p]; a[p] = a[i]; a[i] = t; i = p; }
            }
            public int Pop()
            {
                int top = a[0].v; var last = a[a.Count - 1]; a.RemoveAt(a.Count - 1);
                if (a.Count > 0)
                {
                    a[0] = last; int i = 0;
                    while (true)
                    {
                        int l = i * 2 + 1, r = l + 1, m = i;
                        if (l < a.Count && a[l].k < a[m].k) m = l;
                        if (r < a.Count && a[r].k < a[m].k) m = r;
                        if (m == i) break; var t = a[m]; a[m] = a[i]; a[i] = t; i = m;
                    }
                }
                return top;
            }
        }

        static int[] AStarManaged(byte[] grid, int w, int h, int sx, int sz, int gx, int gz)
        {
            Func<int, int, bool> ok = (x, z) => x >= 0 && z >= 0 && x < w && z < h && grid[z * w + x] == 0;
            if (!ok(sx, sz) || !ok(gx, gz)) return null;
            int N = w * h, s = sz * w + sx, t = gz * w + gx;
            if (s == t) return new[] { s };
            var g = new float[N]; var parent = new int[N]; var closed = new bool[N];
            for (int i = 0; i < N; i++) { g[i] = 1e30f; parent[i] = -1; }
            var open = new Heap(); g[s] = 0; open.Push(0, s);
            int[] DX = { 1, -1, 0, 0, 1, 1, -1, -1 }, DZ = { 0, 0, 1, -1, 1, -1, 1, -1 };
            while (open.Count > 0)
            {
                int cur = open.Pop(); if (closed[cur]) continue; closed[cur] = true; if (cur == t) break;
                int cx = cur % w, cz = cur / w;
                for (int d = 0; d < 8; d++)
                {
                    int nx = cx + DX[d], nz = cz + DZ[d];
                    if (!ok(nx, nz)) continue;
                    if (d >= 4 && (!ok(cx + DX[d], cz) || !ok(cx, cz + DZ[d]))) continue;
                    int ni = nz * w + nx; if (closed[ni]) continue;
                    float ng = g[cur] + (d < 4 ? 1f : 1.41421356f);
                    if (ng < g[ni])
                    {
                        g[ni] = ng; parent[ni] = cur;
                        float dx = Mathf.Abs(nx - gx), dz = Mathf.Abs(nz - gz);
                        open.Push(ng + dx + dz - 0.5858f * Mathf.Min(dx, dz), ni);
                    }
                }
            }
            if (parent[t] < 0) return null;
            var rev = new List<int>(); for (int c = t; c != -1; c = parent[c]) rev.Add(c);
            rev.Reverse(); return rev.ToArray();
        }

        // ---------------- Separation ----------------
        public static void Separation(float[] pos, int n, float radius, float[] force)
        {
            if (Available)
            {
                try { gage_separation(pos, n, radius, force); return; }
                catch (Exception) { state = -1; }
            }
            Array.Clear(force, 0, force.Length);
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                {
                    if (i == j) continue;
                    float ax = pos[2 * i] - pos[2 * j], az = pos[2 * i + 1] - pos[2 * j + 1];
                    float d2 = ax * ax + az * az;
                    if (d2 < radius * radius && d2 > 1e-8f)
                    {
                        float d = Mathf.Sqrt(d2), f = (radius - d) / radius;
                        force[2 * i] += ax / d * f; force[2 * i + 1] += az / d * f;
                    }
                }
        }
    }
}
