using Godot;

namespace GAGE
{
    public enum GameState { Editing, Playing, Won, Lost }

    public partial class GameSession : Node
    {
        public static GameSession I;
        public GameState State = GameState.Editing; public int Score, Health, Target; public string WinText = "You Win!", LoseText = "Game Over";
        public bool Playing { get { return State == GameState.Playing; } }
        public override void _EnterTree() { I = this; }

        public void Begin(SceneData d)
        {
            Score = 0; Health = d.player.health; WinText = d.winText; LoseText = d.loseText;
            int coins = 0; foreach (var e in d.entities) if (e.type == "coin") coins += Mathf.Max(1, e.points);
            Target = coins > 0 ? Mathf.Min(Mathf.Max(1, d.targetScore), coins) : 0;
            State = GameState.Playing;
        }
        public void End() { State = GameState.Editing; }
        public void AddScore(int n) { if (!Playing) return; Score += n; if (Target > 0 && Score >= Target) State = GameState.Won; }
        public void Damage(int n) { if (!Playing) return; Health -= n; if (Health <= 0) { Health = 0; State = GameState.Lost; } }

        float[] pos = new float[2], force = new float[2];
        public override void _Process(double delta)
        {
            if (!Playing) return;
            int n = EnemyAI3D.All.Count; if (n < 2) return;
            if (pos.Length < n * 2) { pos = new float[n * 2]; force = new float[n * 2]; }
            for (int i = 0; i < n; i++) { var p = EnemyAI3D.All[i].GlobalPosition; pos[2 * i] = p.X; pos[2 * i + 1] = p.Z; }
            NativeBridge.Separation(pos, n, 2.2f, force);   // C++ (or C# fallback)
            for (int i = 0; i < n; i++) EnemyAI3D.All[i].Sep = new Vector2(force[2 * i], force[2 * i + 1]);
        }
    }
}
