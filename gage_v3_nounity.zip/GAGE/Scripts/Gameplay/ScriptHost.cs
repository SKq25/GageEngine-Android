using System;
using Godot;
using MoonSharp.Interpreter;
using LuaScript = MoonSharp.Interpreter.Script;

namespace GAGE
{
    /// <summary>
    /// Lua scripting for game logic (MoonSharp, a plain NuGet package). Script: res://game.lua, or user://game.lua if it exists.
    /// Lua API: say(text) score(n) damage(n) spawn(type,x,z) player_x() player_z() ; optional callbacks on_start() on_update(dt)
    /// </summary>
    public partial class ScriptHost : Node
    {
        public static ScriptHost I; public static string Message = ""; public static float MessageTime;
        public static void Say(string s) { Message = s; MessageTime = U.Now; }
        public override void _EnterTree() { I = this; }

        LuaScript lua; DynValue onUpdate;

        public void Begin()
        {
            lua = null; onUpdate = null;
            string code = "";
            try
            {
                string user = System.IO.Path.Combine(OS.GetUserDataDir(), "game.lua");
                code = System.IO.File.Exists(user) ? System.IO.File.ReadAllText(user) : Godot.FileAccess.GetFileAsString("res://game.lua");
            }
            catch (Exception) { }
            if (string.IsNullOrWhiteSpace(code)) return;
            try
            {
                lua = new LuaScript(CoreModules.Preset_SoftSandbox);
                Reg("say", a => { Say(a.Count > 0 ? a[0].CastToString() : ""); return DynValue.Nil; });
                Reg("score", a => { GameSession.I.AddScore((int)a[0].Number); return DynValue.Nil; });
                Reg("damage", a => { GameSession.I.Damage((int)a[0].Number); return DynValue.Nil; });
                Reg("spawn", a => { SceneBuilder.I.SpawnLive(a[0].CastToString(), (float)a[1].Number, (float)a[2].Number); return DynValue.Nil; });
                Reg("player_x", a => DynValue.NewNumber(SceneBuilder.I.Player.GlobalPosition.X));
                Reg("player_z", a => DynValue.NewNumber(SceneBuilder.I.Player.GlobalPosition.Z));
                lua.DoString(code);
                var st = lua.Globals.Get("on_start"); if (st.Type == DataType.Function) lua.Call(st);
                onUpdate = lua.Globals.Get("on_update");
            }
            catch (Exception e) { GD.PrintErr("[GAGE Lua] " + e.Message); lua = null; }
        }

        void Reg(string name, Func<CallbackArguments, DynValue> f) { lua.Globals[name] = DynValue.NewCallback((ctx, args) => f(args)); }

        public override void _Process(double delta)
        {
            if (lua == null || onUpdate == null || onUpdate.Type != DataType.Function || GameSession.I == null || !GameSession.I.Playing) return;
            try { lua.Call(onUpdate, (double)delta); } catch (Exception e) { GD.PrintErr("[GAGE Lua] " + e.Message); onUpdate = null; }
        }
    }
}
