using Godot;

namespace GAGE
{
    /// <summary>Third-person player. Walks on the terrain height field, jumps, is pushed out of trees/houses/rocks. No physics engine needed.</summary>
    public partial class PlayerController3D : Node3D
    {
        public float speed = 6f; float vy;

        public override void _Process(double delta)
        {
            var gs = GameSession.I; var sb = SceneBuilder.I; if (gs == null || sb == null || !gs.Playing || sb.Terrain == null) return;
            float dt = (float)delta;
            var hub = InputHub.I;
            Vector2 inp = hub.Move + hub.KeyMove(); if (inp.Length() > 1f) inp = inp.Normalized();
            var cb = sb.Cam.GlobalTransform.Basis;
            Vector3 f = -cb.Z; f.Y = 0; f = f.Normalized(); Vector3 r = cb.X; r.Y = 0; r = r.Normalized();
            Vector3 mv = (f * inp.Y + r * inp.X) * speed;
            var T = sb.Terrain; var p = GlobalPosition;

            // horizontal move (axis by axis so you slide along steep slopes / obstacles)
            Vector3 np = p; np.X += mv.X * dt;
            if (CanStand(T, np, p)) p.X = np.X;
            np = p; np.Z += mv.Z * dt;
            if (CanStand(T, np, p)) p.Z = np.Z;
            Collide(sb, ref p);

            float h = T.HeightAt(p.X, p.Z);
            bool grounded = p.Y <= h + 0.05f && vy <= 0f;
            if (grounded) { p.Y = h; vy = 0f; if (hub.TakeJump()) vy = 7.5f; }
            else vy -= 20f * dt;
            p.Y += vy * dt; if (p.Y < h) { p.Y = h; vy = 0f; }
            hub.TakeJump();

            float lim = T.Size * 0.5f - 1f; p.X = Mathf.Clamp(p.X, -lim, lim); p.Z = Mathf.Clamp(p.Z, -lim, lim);
            GlobalPosition = p;

            if (inp.LengthSquared() > 0.01f && (mv.X * mv.X + mv.Z * mv.Z) > 0.001f)
            {
                float want = Mathf.Atan2(-mv.X, -mv.Z);      // model faces -Z
                Rotation = new Vector3(0f, Mathf.LerpAngle(Rotation.Y, want, 1f - Mathf.Exp(-12f * dt)), 0f);
            }
        }

        static bool CanStand(TerrainInfo T, Vector3 to, Vector3 from)
        {
            float nh = T.HeightAt(to.X, to.Z), ch = T.HeightAt(from.X, from.Z);
            return !(nh - ch > 0.45f * (to - from).Length() * 3f + 0.12f && T.Slope(to.X, to.Z) > 1.45f);   // ~55 degree slope limit
        }

        static void Collide(SceneBuilder sb, ref Vector3 p)
        {
            foreach (var o in sb.Obstacles)
            {
                float dx = p.X - o.X, dz = p.Z - o.Y, rr = o.Z + 0.4f, d2 = dx * dx + dz * dz;
                if (d2 < rr * rr && d2 > 1e-6f) { float d = Mathf.Sqrt(d2), k = (rr - d) / d; p.X += dx * k; p.Z += dz * k; }
            }
        }
    }
}
