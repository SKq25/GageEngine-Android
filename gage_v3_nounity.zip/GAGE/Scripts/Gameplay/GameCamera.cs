using Godot;

namespace GAGE
{
    /// <summary>One orbit camera for both modes: free editor camera and third-person follow camera. Look input comes from InputHub.</summary>
    public partial class GameCamera : Camera3D
    {
        public Vector3 Pivot; public float Yaw = 30f, Pitch = 45f, Dist = 60f; public Node3D Follow;

        public void Orbit(Vector2 d) { Yaw += d.X * 0.25f; Pitch = Mathf.Clamp(Pitch - d.Y * 0.25f, 5f, 85f); }
        public void Pan(Vector2 d)
        {
            Vector3 r = GlobalTransform.Basis.X; r.Y = 0; r = r.Normalized();
            Vector3 f = -GlobalTransform.Basis.Z; f.Y = 0; f = f.Normalized();
            Pivot += (-r * d.X + f * d.Y) * Dist * 0.0022f;
        }
        public void Zoom(float amount) { Dist = Mathf.Clamp(Dist * (1f - amount), 3f, 160f); }
        public void SetPlayMode(Node3D follow) { Follow = follow; Dist = 7f; Pitch = 22f; Pivot = follow.GlobalPosition + Vector3.Up * 1.6f; }
        public void SetEditMode(Vector3 focus, bool resetView)
        {
            Follow = null;
            if (resetView) { Pivot = focus; Yaw = 30f; Pitch = 45f; Dist = (SceneBuilder.I != null && SceneBuilder.I.Terrain != null ? SceneBuilder.I.Terrain.Size : 120f) * 0.55f; }
            else Dist = Mathf.Max(Dist, 30f);
        }

        public override void _Process(double delta)
        {
            if (Follow != null && GodotObject.IsInstanceValid(Follow))
                Pivot = Pivot.Lerp(Follow.GlobalPosition + Vector3.Up * 1.6f, 1f - Mathf.Exp(-12f * (float)delta));
            float yr = Mathf.DegToRad(Yaw), pr = Mathf.DegToRad(Pitch);
            // direction the camera looks along (pitch>0 looks down)
            Vector3 fwd = new Vector3(Mathf.Sin(yr) * Mathf.Cos(pr), -Mathf.Sin(pr), Mathf.Cos(yr) * Mathf.Cos(pr));
            Vector3 pos = Pivot - fwd * Dist;
            var T = SceneBuilder.I != null ? SceneBuilder.I.Terrain : null;
            if (T != null) pos.Y = Mathf.Max(pos.Y, T.HeightAt(pos.X, pos.Z) + 1.0f);
            if ((Pivot - pos).LengthSquared() < 0.0001f) return;
            LookAtFromPosition(pos, Pivot, Vector3.Up);
        }
    }
}
