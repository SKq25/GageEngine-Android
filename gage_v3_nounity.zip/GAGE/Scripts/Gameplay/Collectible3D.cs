using Godot;

namespace GAGE
{
    /// <summary>Coin behaviour (child of the coin entity): spins, bobs, is collected on touch. netId = shared id for multiplayer.</summary>
    public partial class Collectible3D : Node
    {
        public int points = 1; public int netId = -1; float baseY; bool init, registered; Node3D body;

        public override void _ExitTree()
        {
            Collectible3D c;
            if (registered && MultiplayerClient.Coins.TryGetValue(netId, out c) && c == this) MultiplayerClient.Coins.Remove(netId);
        }

        public override void _Process(double delta)
        {
            var sb = SceneBuilder.I; var gs = GameSession.I; if (sb == null || gs == null || !gs.Playing || sb.Player == null) return;
            if (body == null) body = GetParent() as Node3D; if (body == null) return;
            if (!init) { baseY = body.GlobalPosition.Y; init = true; if (netId >= 0) { MultiplayerClient.Coins[netId] = this; registered = true; } }
            float dt = (float)delta;
            body.RotateY(Mathf.DegToRad(120f) * dt);
            var p = body.GlobalPosition; p.Y = baseY + Mathf.Sin(U.Now * 3f + p.X) * 0.12f; body.GlobalPosition = p;
            if ((sb.Player.GlobalPosition + Vector3.Up - p).LengthSquared() < 1.8f * 1.8f)
            {
                if (MultiplayerClient.I != null && MultiplayerClient.I.Joined) MultiplayerClient.I.Claim(netId, points);
                gs.AddScore(points); body.QueueFree();
            }
        }

        public void Take() { if (body != null) body.QueueFree(); else GetParent().QueueFree(); }
    }
}
