using System.Collections.Generic;
using Godot;

namespace GAGE
{
    /// <summary>Enemy brain (child of the enemy entity): C++ A* pathfinding + crowd separation, chase / patrol / wander.</summary>
    public partial class EnemyAI3D : Node
    {
        public static readonly List<EnemyAI3D> All = new List<EnemyAI3D>();
        public float speed = 3f; public string behavior = "chase"; public Vector2 Sep;
        List<Vector3> path = new List<Vector3>(); int idx; float repath, cooldown; Vector3 home, goal; bool toB, started;
        Node3D body;

        public override void _EnterTree() { All.Add(this); }
        public override void _ExitTree() { All.Remove(this); }

        static Vector3 RandomNear(Vector3 c, float r) { var o = U.RandInCircle(r); return new Vector3(c.X + o.X, c.Y, c.Z + o.Y); }

        public override void _Process(double delta)
        {
            var gs = GameSession.I; var sb = SceneBuilder.I;
            if (gs == null || !gs.Playing || sb == null || sb.Player == null || sb.Nav == null) return;
            if (body == null) body = GetParent() as Node3D; if (body == null) return;
            if (!started) { home = body.GlobalPosition; goal = RandomNear(home, 14f); started = true; }
            float dt = (float)delta; cooldown -= dt;
            Vector3 pp = sb.Player.GlobalPosition, p = body.GlobalPosition;
            float dist = new Vector2(p.X - pp.X, p.Z - pp.Z).Length();
            bool chasing = behavior == "chase" ? dist < 40f : dist < 11f;
            Vector3 target;
            if (chasing) target = pp;
            else if (behavior == "patrol") target = toB ? goal : home;
            else target = goal;
            if (!chasing && new Vector2(p.X - target.X, p.Z - target.Z).Length() < 1.8f)
            {
                if (behavior == "patrol") { if (!toB) goal = RandomNear(home, 16f); toB = !toB; } else goal = RandomNear(home, 18f);
                path.Clear();
            }

            repath -= dt;
            if (repath <= 0f || path.Count == 0) { repath = chasing ? 0.45f : 1.5f; path = sb.Nav.FindPath(p, target); idx = path.Count > 1 ? 1 : 0; }
            Vector3 move = Vector3.Zero;
            if (chasing && dist < 3.5f) move = new Vector3(pp.X - p.X, 0, pp.Z - p.Z).Normalized();
            else if (idx < path.Count)
            {
                Vector3 wp = path[idx]; Vector3 d = new Vector3(wp.X - p.X, 0, wp.Z - p.Z);
                if (d.Length() < 0.7f) idx++; else move = d.Normalized();
            }
            move += new Vector3(Sep.X, 0, Sep.Y) * 0.8f;
            if (move.LengthSquared() > 0.0001f)
            {
                move = move.Normalized() * speed * dt; p += move;
                float want = Mathf.Atan2(-move.X, -move.Z);
                body.Rotation = new Vector3(0f, Mathf.LerpAngle(body.Rotation.Y, want, 1f - Mathf.Exp(-10f * dt)), 0f);
            }
            p.Y = sb.Terrain.HeightAt(p.X, p.Z); body.GlobalPosition = p;
            if (dist < 1.5f && cooldown <= 0f) { gs.Damage(1); cooldown = 1.0f; }
        }
    }
}
