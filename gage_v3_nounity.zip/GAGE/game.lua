-- GAGE Lua game script (needs MoonSharp, see README). Runs when you press PLAY.
local t = 0
local spawned = false

function on_start()
  say("Lua script chalu! Coins jama karo.")
end

function on_update(dt)
  t = t + dt
  -- after 20 seconds, drop a bonus coin near the player (once)
  if t > 20 and not spawned then
    spawned = true
    spawn("coin", player_x() + 4, player_z() + 4)
    say("Bonus coin aa gaya!")
  end
end
