# GAGE v3: Unity-free (Godot 4 + C# + C++)

Unity poora hata diya: **koi Unity license / account / login nahi**. Engine ab **Godot 4.3 (.NET)** hai (MIT, free, open source).
Code abhi bhi **C#** (game/engine layer) aur **C++** (`Native/gage_native.cpp`: terrain noise, A* pathfinding, crowd separation) me hai.
Saare features wahi: 3D terrain + water, sun/sky/fog/time-of-day, realism (shadows, ACES tonemap, glow, SSAO, MSAA, procedural normal/detail maps),
drag&drop editor, AI GENERATE/EDIT (Gemini 2.5 Flash), AI NPC, enemy AI, Lua, Sketchfab import, online co-op, SAVE/LOAD/EXPORT, Player-APK.

## Setup (5 min, desktop)
1. Godot **4.3 .NET (mono)** download karo: godotengine.org. Plus .NET 8 SDK.
2. Godot me `GAGE` folder **Import** (project.godot) -> Build (hammer) -> Play. (NuGet se MoonSharp khud aata hai.)
3. AI/multiplayer server: `cd Server && npm start` (`Server/.env` me `OPENROUTER_API_KEY`). `gage_config.json` me `endpoint` set karo.
   Phone ke liye server https pe deploy karo (Render/Railway) aur `endpoint` badlo.

## APK (bina kuch install kiye)
GitHub pe repo daalo -> Actions -> **Build Android APK** -> Run. Koi secret/license nahi chahiye.
Export flow: editor me **EXPORT** -> `<Game>_game.zip` -> repo root me `game.zip` -> workflow Player APK banata hai.

## Folder
- `Scripts/Core` data, config, bundle | `Scripts/World` terrain, props, sky, nav, realism | `Scripts/Gameplay` player, enemy, coin, camera, Lua
- `Scripts/UI` UI + input | `Scripts/AI` | `Scripts/Net` | `Scripts/Store` Sketchfab | `Scripts/Native` C#<->C++ bridge
- `Native/` C++ (`build_desktop.sh` -> `Native/bin`) | `Server/` Node proxy + multiplayer (unchanged, tests pass)
- Apne realistic models: `Prefabs/<type>.tscn` (tree.tscn, house.tscn, enemy.tscn...), model -Z ki taraf dekhe. Lua: `game.lua`.

## Sach baat (limits)
- **C# code maine compile/run nahi kiya** (yaha .NET/Godot download nahi ho sakta). Pehle Unity version jaisa hi: padhkar likha hai. Verified: C++ (build+test), Node server (`node test_mp.js`). Pehli baar build karne par error aaye to Console text bhej do, theek kar dunga.
- Android APK default me C++ ki jagah C# fallback use karta hai (same result, thoda slow). C++ .so ke liye `Native/build_android.sh` + Godot Gradle build.
- Export zip Downloads me na ban paye to app folder me banta hai, aur game JSON clipboard me copy hota hai.
- Mobile renderer me SSAO nahi hota (desktop pe hota hai).
