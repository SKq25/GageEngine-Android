// GAGE AI proxy. The OpenRouter key lives ONLY here (in .env), never inside the game/APK.
// The model is locked to Gemini 2.5 Flash: whatever the client sends, nothing else is ever used.
const http = require('http');
const mp = require('./multiplayer');
const fs = require('fs');
const path = require('path');

try {
  for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch (e) { /* no .env: use real environment variables */ }

const KEY = process.env.OPENROUTER_API_KEY;
const MODEL = 'google/gemini-2.5-flash';
const PORT = process.env.PORT || 8787;
const TOKENS = (process.env.ACCESS_TOKENS || '').split(',').map(s => s.trim()).filter(Boolean);
const RATE = parseInt(process.env.RATE_PER_MIN || '30', 10);
const hits = new Map();

function limited(ip) {
  const now = Date.now();
  const a = (hits.get(ip) || []).filter(t => now - t < 60000);
  a.push(now); hits.set(ip, a);
  return a.length > RATE;
}
function send(res, code, obj) {
  res.writeHead(code, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, X-GAGE-Access',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS'
  });
  res.end(code === 204 ? undefined : JSON.stringify(obj));
}

// ---- multiplayer (see multiplayer.js) ----
function handleMp(req, res) {
  if (TOKENS.length && !TOKENS.includes(req.headers['x-gage-access'] || '')) return send(res, 401, { error: 'bad access token' });
  let body = '', tooBig = false;
  req.on('data', c => { body += c; if (body.length > 300000) { tooBig = true; req.destroy(); } });
  req.on('end', () => {
    if (tooBig) return;
    let j; try { j = JSON.parse(body || '{}'); } catch (e) { return send(res, 400, { error: 'invalid json' }); }
    const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress);
    if (mpLimited(ip)) return send(res, 429, { error: 'too many requests' });
    try { const [code, obj] = mp.handle(req.url.split('?')[0], j || {}); send(res, code, obj); }
    catch (e) { send(res, 500, { error: 'mp failed: ' + e.message }); }
  });
}
const mpHits = new Map();
function mpLimited(ip) {   // sync runs ~10/s per player, so a separate, bigger budget than the AI chat
  const now = Date.now(); const a = (mpHits.get(ip) || []).filter(t => now - t < 1000); a.push(now); mpHits.set(ip, a);
  return a.length > 40;
}

http.createServer((req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204);
  if (req.url === '/health') return send(res, 200, { ok: true, model: MODEL, keyLoaded: !!KEY });
  if (req.url === '/mp/health') return send(res, 200, mp.stats());
  if (req.method === 'POST' && req.url.startsWith('/mp/')) return handleMp(req, res);
  if (req.method !== 'POST' || req.url !== '/api/chat') return send(res, 404, { error: 'not found' });
  if (!KEY) return send(res, 500, { error: 'server key missing (.env)' });
  if (TOKENS.length && !TOKENS.includes(req.headers['x-gage-access'] || '')) return send(res, 401, { error: 'bad access token' });
  const ip = String(req.headers['x-forwarded-for'] || req.socket.remoteAddress);
  if (limited(ip)) return send(res, 429, { error: 'too many requests' });

  let body = '';
  req.on('data', c => { body += c; if (body.length > 200000) req.destroy(); });
  req.on('end', async () => {
    let j;
    try { j = JSON.parse(body); } catch (e) { return send(res, 400, { error: 'invalid json' }); }
    const msgs = Array.isArray(j.messages) ? j.messages : [];
    const ok = msgs.length > 0 && msgs.length < 40 && msgs.every(m => m && ['system', 'user', 'assistant'].includes(m.role) && typeof m.content === 'string');
    if (!ok) return send(res, 400, { error: 'bad messages' });
    const payload = {
      model: MODEL,                                                   // forced, client value ignored
      messages: msgs,
      temperature: Math.min(1.5, Math.max(0, Number(j.temperature) || 0.7)),
      max_tokens: Math.min(8000, Math.max(50, parseInt(j.max_tokens, 10) || 2000))
    };
    try {
      const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + KEY, 'HTTP-Referer': 'https://gage.local', 'X-Title': 'GAGE' },
        body: JSON.stringify(payload)
      });
      const text = await r.text();
      res.writeHead(r.status, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
      res.end(text);
    } catch (e) { send(res, 502, { error: 'upstream failed: ' + e.message }); }
  });
}).listen(PORT, () => console.log('GAGE proxy on :' + PORT + ' model=' + MODEL + ' key=' + (KEY ? 'loaded' : 'MISSING') + ' tokens=' + TOKENS.length));
