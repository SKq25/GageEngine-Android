// Run: node test_mp.js   (starts the server on a test port and exercises the multiplayer API)
const { spawn } = require('child_process');
const assert = require('assert');
const PORT = 8799;
const srv = spawn('node', ['server.js'], { env: { ...process.env, PORT, OPENROUTER_API_KEY: 'test' }, cwd: __dirname });
const post = async (p, b) => { const r = await fetch(`http://localhost:${PORT}${p}`, { method: 'POST', body: JSON.stringify(b) }); return [r.status, await r.json()]; };
(async () => {
  await new Promise(r => setTimeout(r, 700));
  const scene = { world: { title: 'T' }, entities: [{ type: 'coin' }, { type: 'coin' }, { type: 'tree' }] };
  let [s, A] = await post('/mp/host', { name: 'Ann', scene }); assert.equal(s, 200); assert.equal(A.room.length, 4);
  let [s2, B] = await post('/mp/join', { room: A.room.toLowerCase(), name: 'Bob<script>' }); assert.equal(s2, 200);
  assert.equal(B.scene.entities.length, 3); assert.equal(B.players.length, 1);
  [s] = await post('/mp/join', { room: 'ZZZZ', name: 'x' }); assert.equal(s, 404);
  [s] = await post('/mp/sync', { room: A.room, id: A.id, token: 'bad' }); assert.equal(s, 401);
  // A moves and claims coin 0
  let [, ra] = await post('/mp/sync', { room: A.room, id: A.id, token: A.token, x: 1, y: 2, z: 3, ry: 90, pl: true, claim: [{ c: 0, p: 1 }] });
  assert.equal(ra.score, 1); assert.equal(ra.players.length, 1); assert.equal(ra.players[0].name, 'Bobscript'.slice(0, 16) === ra.players[0].name ? ra.players[0].name : '');
  // B sees A's position and the taken coin; B tries to claim the same coin -> denied, and a free coin -> ok
  let [, rb] = await post('/mp/sync', { room: A.room, id: B.id, token: B.token, x: 5, y: 0, z: 5, ry: 0, claim: [{ c: 0, p: 1 }, { c: 1, p: 1 }] });
  assert.deepEqual(rb.denied, [{ c: 0, p: 1 }]); assert.equal(rb.score, 1); assert.equal(rb.team, 2);
  const a = rb.players.find(p => p.id === A.id); assert.equal(a.x, 1); assert.equal(a.ry, 90); assert.equal(a.pl, true); assert.equal(a.host, true);
  // re-claiming own coin is not "denied"
  [, rb] = await post('/mp/sync', { room: A.room, id: B.id, token: B.token, claim: [{ c: 1, p: 1 }] }); assert.equal(rb.denied.length, 0); assert.equal(rb.score, 1);
  // garbage input does not crash
  [s] = await post('/mp/sync', { room: A.room, id: A.id, token: A.token, x: 'NaN', claim: 'oops' }); assert.equal(s, 200);
  [s] = await post('/mp/host', { name: 'x', scene: { entities: 'no' } }); assert.equal(s, 400);
  // room limit 8
  for (let i = 0; i < 6; i++) { [s] = await post('/mp/join', { room: A.room, name: 'p' + i }); assert.equal(s, 200); }
  [s] = await post('/mp/join', { room: A.room, name: 'ninth' }); assert.equal(s, 409);
  await post('/mp/leave', { room: A.room, id: B.id, token: B.token });
  [s] = await post('/mp/join', { room: A.room, name: 'again' }); assert.equal(s, 200);
  const h = await (await fetch(`http://localhost:${PORT}/mp/health`)).json(); assert.equal(h.rooms, 1);
  console.log('MULTIPLAYER SERVER TESTS PASSED', JSON.stringify(h));
})().catch(e => { console.error('FAIL', e); process.exitCode = 1; }).finally(() => srv.kill());
