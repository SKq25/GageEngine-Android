// GAGE multiplayer relay (HTTP, no extra npm packages, works behind https hosts like Render/Railway).
// Rooms hold: the host's scene JSON, players (position snapshots), and shared coin pickups.
// Coin pickups are server-authoritative: the first player to claim a coin id wins it.
//
// Endpoints (all POST, JSON):
//   /mp/host   {name, scene}                 -> {room, id, token, scene}
//   /mp/join   {room, name}                  -> {room, id, token, scene, players, taken}
//   /mp/sync   {room, id, token, x,y,z,ry, claim:[{c,p}]}  -> {players, taken, denied, score, t}
//   /mp/leave  {room, id, token}             -> {ok:true}
//   GET /mp/health                           -> {rooms, players}

const crypto = require('crypto');

const MAX_PLAYERS = 8;
const MAX_ROOMS = 200;
const STALE_MS = 12000;      // player removed if no sync for this long
const ROOM_IDLE_MS = 600000; // empty room removed after this
const MAX_SCENE_BYTES = 250000;
const rooms = new Map();

function code() {
  const A = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  for (let tries = 0; tries < 50; tries++) {
    let s = '';
    const b = crypto.randomBytes(4);
    for (let i = 0; i < 4; i++) s += A[b[i] % A.length];
    if (!rooms.has(s)) return s;
  }
  return null;
}
const num = (v, d = 0) => (typeof v === 'number' && isFinite(v) ? v : d);
const cleanName = (n) => String(n || 'Player').replace(/[^\p{L}\p{N} _-]/gu, '').trim().slice(0, 16) || 'Player';

function prune(now) {
  for (const [rc, r] of rooms) {
    for (const [pid, p] of r.players) if (now - p.seen > STALE_MS) r.players.delete(pid);
    if (r.players.size === 0 && now - r.last > ROOM_IDLE_MS) rooms.delete(rc);
    if (r.players.size > 0 && !r.players.has(r.hostId)) r.hostId = r.players.keys().next().value;
  }
}
setInterval(() => prune(Date.now()), 5000).unref();

function view(r, now) {
  const players = [];
  for (const [id, p] of r.players) players.push({ id, name: p.name, x: p.x, y: p.y, z: p.z, ry: p.ry, pl: !!p.pl, score: p.score, host: id === r.hostId, age: now - p.seen });
  return players;
}

function newPlayer(r, name, now) {
  const id = crypto.randomBytes(3).toString('hex');
  const token = crypto.randomBytes(12).toString('hex');
  r.players.set(id, { name: cleanName(name), token, x: 0, y: 0, z: 0, ry: 0, score: 0, seen: now });
  r.last = now;
  return { id, token };
}

function auth(r, j) {
  const p = r && r.players.get(String(j.id));
  return p && p.token === j.token ? p : null;
}

// returns [statusCode, object]
function handle(path, j, now = Date.now()) {
  prune(now);
  if (path === '/mp/host') {
    if (rooms.size >= MAX_ROOMS) return [503, { error: 'server busy, try later' }];
    const scene = j.scene;
    if (!scene || typeof scene !== 'object' || !Array.isArray(scene.entities)) return [400, { error: 'scene missing' }];
    if (JSON.stringify(scene).length > MAX_SCENE_BYTES) return [413, { error: 'scene too large' }];
    const rc = code(); if (!rc) return [503, { error: 'no room codes free' }];
    const r = { scene, players: new Map(), taken: new Map(), hostId: '', last: now };
    rooms.set(rc, r);
    const { id, token } = newPlayer(r, j.name, now); r.hostId = id;
    return [200, { room: rc, id, token, scene }];
  }
  const rc = String(j.room || '').toUpperCase();
  const r = rooms.get(rc);
  if (!r) return [404, { error: 'room not found' }];

  if (path === '/mp/join') {
    if (r.players.size >= MAX_PLAYERS) return [409, { error: 'room full' }];
    const { id, token } = newPlayer(r, j.name, now);
    const taken = []; for (const [c, t] of r.taken) taken.push({ c, p: t.p, by: t.by });
    return [200, { room: rc, id, token, scene: r.scene, players: view(r, now).filter(p => p.id !== id), taken }];
  }
  const me = auth(r, j);
  if (!me) return [401, { error: 'bad player token' }];

  if (path === '/mp/sync') {
    me.seen = now; r.last = now;
    me.x = num(j.x, me.x); me.y = num(j.y, me.y); me.z = num(j.z, me.z); me.ry = num(j.ry, me.ry); me.pl = j.pl === true;
    const denied = [];
    if (Array.isArray(j.claim)) {
      for (const c of j.claim.slice(0, 20)) {
        const cid = parseInt(c && c.c, 10); const pts = Math.min(10, Math.max(1, parseInt(c && c.p, 10) || 1));
        if (!(cid >= 0 && cid < 100000)) continue;
        if (r.taken.has(cid)) { if (r.taken.get(cid).by !== j.id) denied.push({ c: cid, p: pts }); }
        else { r.taken.set(cid, { by: j.id, p: pts }); me.score += pts; }
      }
    }
    let team = 0; for (const t of r.taken.values()) team += t.p;
    const players = view(r, now).filter(p => p.id !== j.id);
    // taken: list of {c,p,by} so clients can remove coins and credit team score
    const taken = []; for (const [c, t] of r.taken) taken.push({ c, p: t.p, by: t.by });
    return [200, { players, taken, denied, score: me.score, team, t: now }];
  }
  if (path === '/mp/leave') { r.players.delete(String(j.id)); return [200, { ok: true }]; }
  return [404, { error: 'not found' }];
}

function stats() {
  let players = 0; for (const r of rooms.values()) players += r.players.size;
  return { rooms: rooms.size, players };
}

module.exports = { handle, stats, _rooms: rooms };
