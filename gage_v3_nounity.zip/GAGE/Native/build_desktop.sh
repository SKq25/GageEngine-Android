#!/usr/bin/env bash
# Builds the C++ core for this computer into Native/bin (GAGE finds it there automatically).
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
cmake -S "$HERE" -B "$HERE/build-desktop" -DCMAKE_BUILD_TYPE=Release && cmake --build "$HERE/build-desktop" --config Release
mkdir -p "$HERE/bin"
cp "$HERE"/build-desktop/libgage_native.* "$HERE/bin/" 2>/dev/null || cp "$HERE"/build-desktop/Release/gage_native.dll "$HERE/bin/"
echo "Done: Native/bin"
