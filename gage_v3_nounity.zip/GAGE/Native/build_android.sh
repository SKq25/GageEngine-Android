#!/usr/bin/env bash
# Builds libgage_native.so for Android into Native/bin/android/<abi>/ . Needs ANDROID_NDK_HOME.
# (Default APK build uses the C# fallback; to ship the .so, use Godot's Gradle build and copy these into android/build/libs/<abi>/.)
set -e
: "${ANDROID_NDK_HOME:?set ANDROID_NDK_HOME}"
HERE="$(cd "$(dirname "$0")" && pwd)"
for ABI in arm64-v8a armeabi-v7a x86_64; do
  OUT="$HERE/build-$ABI"; mkdir -p "$OUT"
  cmake -S "$HERE" -B "$OUT" -DCMAKE_TOOLCHAIN_FILE="$ANDROID_NDK_HOME/build/cmake/android.toolchain.cmake" -DANDROID_ABI=$ABI -DANDROID_PLATFORM=android-24 -DCMAKE_BUILD_TYPE=Release
  cmake --build "$OUT" --config Release
  mkdir -p "$HERE/bin/android/$ABI"; cp "$OUT/libgage_native.so" "$HERE/bin/android/$ABI/"
done
