// GAGE native core (C++17). Called from C# via P/Invoke (see Assets/GAGE/Native/NativeBridge.cs).
// Heavy math lives here: terrain noise, grid A* pathfinding, spatial separation.
#include <cstdint>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <queue>
#include <algorithm>

#if defined(_WIN32)
  #define GAGE_API extern "C" __declspec(dllexport)
#else
  #define GAGE_API extern "C" __attribute__((visibility("default")))
#endif

static inline uint32_t hash2(int x, int y, uint32_t seed) {
    uint32_t h = (uint32_t)x * 374761393u + (uint32_t)y * 668265263u + seed * 2246822519u;
    h = (h ^ (h >> 13)) * 1274126177u;
    return h ^ (h >> 16);
}
static inline float grad(int ix, int iy, float dx, float dy, uint32_t seed) {
    float a = (hash2(ix, iy, seed) & 0xFFFF) * (6.2831853f / 65536.0f);
    return std::cos(a) * dx + std::sin(a) * dy;
}
static inline float fade(float t) { return t * t * t * (t * (t * 6.f - 15.f) + 10.f); }

// Perlin gradient noise, range ~[-1,1]
static float perlin(float x, float y, uint32_t seed) {
    int x0 = (int)std::floor(x), y0 = (int)std::floor(y);
    float fx = x - x0, fy = y - y0;
    float u = fade(fx), v = fade(fy);
    float n00 = grad(x0, y0, fx, fy, seed),         n10 = grad(x0 + 1, y0, fx - 1, fy, seed);
    float n01 = grad(x0, y0 + 1, fx, fy - 1, seed), n11 = grad(x0 + 1, y0 + 1, fx - 1, fy - 1, seed);
    float a = n00 + u * (n10 - n00), b = n01 + u * (n11 - n01);
    return (a + v * (b - a)) * 1.4142f;
}

GAGE_API int gage_version() { return 100; }

// Fills out[w*h] with heights in [0,1]. fBm + ridged mix. Row-major: out[z*w + x].
GAGE_API void gage_heightmap(float* out, int w, int h, float scale, int seed, int octaves, float persistence, float ridged) {
    if (!out || w <= 0 || h <= 0) return;
    octaves = std::max(1, std::min(octaves, 10));
    float mn = 1e9f, mx = -1e9f;
    for (int z = 0; z < h; ++z) {
        for (int x = 0; x < w; ++x) {
            float amp = 1.f, freq = 1.f, sum = 0.f, norm = 0.f;
            for (int o = 0; o < octaves; ++o) {
                float n = perlin(x / (float)w * scale * freq, z / (float)h * scale * freq, (uint32_t)seed + o * 131u);
                float r = 1.f - std::fabs(n);          // ridged
                n = n * (1.f - ridged) + (r * r * 2.f - 1.f) * ridged;
                sum += n * amp; norm += amp;
                amp *= persistence; freq *= 2.f;
            }
            float v = sum / norm;
            out[z * w + x] = v;
            mn = std::min(mn, v); mx = std::max(mx, v);
        }
    }
    float range = (mx - mn) > 1e-6f ? (mx - mn) : 1.f;
    for (int i = 0; i < w * h; ++i) out[i] = (out[i] - mn) / range;
}

// Grid A* (8-directional, no corner cutting). grid: 0 = walkable, non-zero = blocked.
// Writes cell indices (z*w+x) from start to goal into outPath. Returns length, or 0 if no path.
GAGE_API int gage_astar(const uint8_t* grid, int w, int h, int sx, int sz, int gx, int gz, int* outPath, int maxLen) {
    if (!grid || !outPath || maxLen <= 0) return 0;
    auto ok = [&](int x, int z) { return x >= 0 && z >= 0 && x < w && z < h && grid[z * w + x] == 0; };
    if (!ok(sx, sz) || !ok(gx, gz)) return 0;
    if (sx == gx && sz == gz) { outPath[0] = sz * w + sx; return 1; }

    const int N = w * h;
    std::vector<float> g(N, 1e30f);
    std::vector<int> parent(N, -1);
    std::vector<uint8_t> closed(N, 0);
    typedef std::pair<float, int> QN;
    std::priority_queue<QN, std::vector<QN>, std::greater<QN>> open;

    auto heur = [&](int x, int z) {
        float dx = (float)std::abs(x - gx), dz = (float)std::abs(z - gz);
        return (dx + dz) + (1.41421356f - 2.f) * std::min(dx, dz);   // octile
    };
    int s = sz * w + sx, t = gz * w + gx;
    g[s] = 0; open.push({heur(sx, sz), s});
    static const int DX[8] = {1,-1,0,0,1,1,-1,-1}, DZ[8] = {0,0,1,-1,1,-1,1,-1};

    while (!open.empty()) {
        int cur = open.top().second; open.pop();
        if (closed[cur]) continue;
        closed[cur] = 1;
        if (cur == t) break;
        int cx = cur % w, cz = cur / w;
        for (int d = 0; d < 8; ++d) {
            int nx = cx + DX[d], nz = cz + DZ[d];
            if (!ok(nx, nz)) continue;
            if (d >= 4 && (!ok(cx + DX[d], cz) || !ok(cx, cz + DZ[d]))) continue; // no corner cutting
            int ni = nz * w + nx;
            if (closed[ni]) continue;
            float ng = g[cur] + (d < 4 ? 1.f : 1.41421356f);
            if (ng < g[ni]) { g[ni] = ng; parent[ni] = cur; open.push({ng + heur(nx, nz), ni}); }
        }
    }
    if (parent[t] < 0) return 0;
    std::vector<int> rev;
    for (int c = t; c != -1; c = parent[c]) rev.push_back(c);
    int len = (int)rev.size();
    if (len > maxLen) return 0;
    for (int i = 0; i < len; ++i) outPath[i] = rev[len - 1 - i];
    return len;
}

// Crowd separation: for each of n agents (xz pairs in pos[2n]) writes a push vector to outForce[2n]
// away from neighbours closer than 'radius'. Uses a sorted spatial hash, ~O(n log n).
GAGE_API void gage_separation(const float* pos, int n, float radius, float* outForce) {
    if (!pos || !outForce || n <= 0 || radius <= 0) return;
    std::fill(outForce, outForce + 2 * n, 0.f);
    const float cell = radius;
    auto key = [](int cx, int cz) { return ((int64_t)cx << 32) ^ (int64_t)(uint32_t)cz; };
    std::vector<std::pair<int64_t, int>> bucket(n);
    for (int i = 0; i < n; ++i)
        bucket[i] = { key((int)std::floor(pos[2*i] / cell), (int)std::floor(pos[2*i+1] / cell)), i };
    std::sort(bucket.begin(), bucket.end());
    for (int i = 0; i < n; ++i) {
        int cx = (int)std::floor(pos[2*i] / cell), cz = (int)std::floor(pos[2*i+1] / cell);
        for (int dx = -1; dx <= 1; ++dx) for (int dz = -1; dz <= 1; ++dz) {
            int64_t k = key(cx + dx, cz + dz);
            auto it = std::lower_bound(bucket.begin(), bucket.end(), std::make_pair(k, -1));
            for (; it != bucket.end() && it->first == k; ++it) {
                int j = it->second; if (j == i) continue;
                float ax = pos[2*i] - pos[2*j], az = pos[2*i+1] - pos[2*j+1];
                float d2 = ax*ax + az*az;
                if (d2 < radius * radius && d2 > 1e-8f) {
                    float d = std::sqrt(d2), f = (radius - d) / radius;
                    outForce[2*i] += ax / d * f; outForce[2*i+1] += az / d * f;
                }
            }
        }
    }
}
