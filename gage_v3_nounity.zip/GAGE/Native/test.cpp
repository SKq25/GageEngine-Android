#include <cstdio>
#include <vector>
#include <cstdint>
extern "C" { int gage_version(); void gage_heightmap(float*,int,int,float,int,int,float,float);
 int gage_astar(const uint8_t*,int,int,int,int,int,int,int*,int); void gage_separation(const float*,int,float,float*); }
int main(){
  int w=64,h=64; std::vector<float> hm(w*h); gage_heightmap(hm.data(),w,h,4,7,5,0.5f,0.3f);
  float mn=9,mx=-9; for(float v:hm){ if(v<mn)mn=v; if(v>mx)mx=v; } printf("heightmap range %.3f..%.3f\n",mn,mx);
  std::vector<uint8_t> g(w*h,0); for(int z=0;z<50;++z) g[z*w+30]=1;
  std::vector<int> p(w*h); int n=gage_astar(g.data(),w,h,5,5,55,5,p.data(),w*h); printf("path len %d\n",n);
  int blocked=0; for(int i=0;i<n;++i) if(g[p[i]]) blocked++; printf("blocked cells on path %d\n",blocked);
  float pos[]={0,0, 0.5f,0, 5,5}; float f[6]; gage_separation(pos,3,1.f,f); printf("force0 %.2f %.2f | force2 %.2f %.2f\n",f[0],f[1],f[4],f[5]);
  return 0; }
